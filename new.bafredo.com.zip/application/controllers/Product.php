<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('CategoryModel', 'category');
        $this->load->model('ProductModel', 'product');
    }

    public function detail($slug)
	{
        $product = $this->product->findBySlug($slug);
	    $gallery = $this->product->gallery($product->getId());
        $subCategory = $this->category->getOneById($product->getCategoryId());
        $mainCategory = $this->category->getMainCategoryById($subCategory->getCategoryId());
        $this->twig->display('product/detail', compact('product', 'gallery', 'mainCategory'));
	}

	public function all()
    {
        $parent_slug = 'all';
        $subCategories = array();
        $products = $this->product->findAll();

        $this->twig->display('category', compact('products', 'subCategories', 'parent_slug'));
    }

    public function sales()
    {
        $parent_slug = 'sales';
        $subCategories = array();
        $products = $this->product->findAll();

        $this->twig->display('category', compact('products', 'subCategories', 'parent_slug'));
    }

    public function newArrival()
    {
        $parent_slug = 'new';
        $subCategories = array();
        $products = $this->product->newArrival();

        $this->twig->display('category', compact('products', 'subCategories', 'parent_slug'));
    }
}
