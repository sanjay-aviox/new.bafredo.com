<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('ProductModel', 'product');
        $this->load->model('BlogModel', 'blog');
        $this->load->model('SettingModel', 'sm');
        $this->load->model('DashboardModel', 'dbm');

    }

    public function index()
	{
        $new_arrival_products = $this->product->newArrival(4);
        $featured_products = $this->product->featured(4);
        $specail_products = $this->product->special(4);
        $blogs = $this->blog->getLatest(array('id' => 'DESC'), 3);

        $this->twig->display('home', compact(
            'new_arrival_products',
            'featured_products',
            'specail_products',
            'blogs'
        ));

            //$this->dbm->updatesitorcount();
    }

	public function prefetch()
    {
        $result = $this->db->select('id, name, slug, description, CONCAT("'.asset('uploads/product/thumbnail/').'", image) AS thumbnail, price, currency, sku, brand')
            ->limit(10)
            ->get("products")
            ->result();

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($result));
    }
    public function subscribe()
    {
        $response = $this->sm->subscribe_email($this->input->post("email"));
        echo  $response;
    }
    public function typeahead()
    {
        $q = $this->input->get("q", true);

        $result = $this->db->select('id, name, slug, description, CONCAT("'.asset('uploads/product/thumbnail/').'", image) AS thumbnail, price, currency, sku, brand')
            ->like("name", $q)
            ->get("products")
            ->result();

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($result));
    }

    public function search()
    {
        $slug = $this->input->get("slug", true);

        $this->load->model('CategoryModel', 'category');
        $this->load->model('ProductModel', 'product');

        $product = $this->product->findBySlug($slug);
        $gallery = $this->product->gallery($product->getId());
        $subCategory = $this->category->getOneById($product->getCategoryId());
        $mainCategory = $this->category->getMainCategoryById($subCategory->getCategoryId());

        $this->twig->display('product/detail', compact('product', 'gallery', 'mainCategory'));
    }
}
