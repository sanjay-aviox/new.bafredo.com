<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: dell
 * Date: 6/24/2019
 * Time: 12:44 AM
 */
class Wishlist extends MY_Controller
{
    public function add()
    {
        $current_user = getAuthUser('user');

        $product_id = $this->input->post('product_id');
        $dataAdapter = $this->db->where("product_id", $product_id)
                                ->where("user_id", $current_user->getId())
                                ->get("wishlist");
        if ($dataAdapter->num_rows() <= 0) {
            $this->db->insert("wishlist", array(
                "user_id" => $current_user->getId(),
                "product_id" => $product_id
            ));
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode(array(
            'status' => 'success',
            'message' => 'Product added to Wishlist'
        )));
    }
}