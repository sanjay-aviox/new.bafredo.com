<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: masoodurrehman42@gmail.com
 * Date: 4/25/2019
 * Time: 10:08 PM
 */

class Page extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->library('doctrine');
        $this->em = $this->doctrine->em;
    }

    public function index($slug)
    {
        $this->load->Model('PageModel','PM');
        $data = array();
        if ($slug == 'contact-us') {
            $post = $this->input->post();
            if(!empty($post))
            {
                $this->PM->insert_contact_us($post);
                $data["success"] = true;
            }
            $this->twig->display("page/contact-us",compact('data'));

        } else {
            $page = $this->doctrine->em->getRepository("Entity\Page")->findOneBySlug($slug);
            $this->twig->display("page/common", compact('page'));
        }
    }

    public function template($page)
    {
        $this->twig->display("template/{$page}");
    }
}