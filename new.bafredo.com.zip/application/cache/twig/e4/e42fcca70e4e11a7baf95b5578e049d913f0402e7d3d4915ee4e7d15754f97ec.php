<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/home/product_list.twig */
class __TwigTemplate_0a04acd93f978d5d024619c42804f42512f15578b6a4ba2aa729e823cfb5ec72 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"lineFrame pl\">
    <div class=\"productTitle\" data-pc=\"Latest\">
        <i class=\"latest\"></i><b>New Arrival</b><span>Popular New Releases</span>
    </div>
    <div class=\"productList\">
        <ul class=\"simpleMode\">
            ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["new_arrival_products"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 8
            echo "                <li>";
            echo twig_include($this->env, $context, "partials/product.twig");
            echo "</li>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 10
        echo "        </ul>
    </div>

    <div class=\"clear\"></div>
    <div class=\"newaproductd\">
        <p><a href=\"#\" target=\"_self\"><img src=\"";
        // line 15
        echo asset("front/image/blog/featured/4.jpg");
        echo "\" style=\"width: 1200px;\"></a><br></p>
    </div>

    <div class=\"clear\"></div>
    <div class=\"productTitle\" data-pc=\"Featured\">
        <i class=\"featured\"></i><b>Featured Products</b><span>Check Our Top-selling Releases</span>
    </div>
    <div class=\"productList\">
        <ul class=\"simpleMode\">
            ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["featured_products"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 25
            echo "                <li>";
            echo twig_include($this->env, $context, "partials/product.twig");
            echo "</li>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "        </ul>
    </div>

    <div class=\"clear\"></div>
    <div class=\"productTitle\" data-pc=\"Specials\">
        <i class=\"specials\"></i><b>Specials</b>
    </div>
    <div class=\"productList\">
        <ul class=\"simpleMode\">
            ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["specail_products"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 37
            echo "                <li>";
            echo twig_include($this->env, $context, "partials/product.twig");
            echo "</li>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "        </ul>
    </div>

    <div class=\"clear\"></div>
    <div class=\"newaproductd\">
        <p>
            <a href=\"";
        // line 45
        echo twig_escape_filter($this->env, base_url("detail"), "html", null, true);
        echo "\" target=\"_self\">
                <img src=\"";
        // line 46
        echo asset("front/image/blog/featured/3.jpg");
        echo "\" style=\"width: 1200px;\" alt=\"Gravity: Analog Electrical Conductivity Sensor / Meter For Arduino\" title=\"Gravity: Analog Electrical Conductivity Sensor / Meter For Arduino\">
            </a>
            <br>
        </p>
    </div>

    <div class=\"clear\"></div>
    <div class=\"productTitle\" data-pc=\"heading_latest_title\">
        <i class=\"featured\"></i><b>Projects & Tutorials</b>
        <span class=\"more\"><a target=\"_blank\" href=\"#\">See More</a></span>
    </div>

    <div class=\"blogList\">
        ";
        // line 59
        echo twig_include($this->env, $context, "partials/home/bloglist.twig");
        echo "
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "partials/home/product_list.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  198 => 59,  182 => 46,  178 => 45,  170 => 39,  153 => 37,  136 => 36,  125 => 27,  108 => 25,  91 => 24,  79 => 15,  72 => 10,  55 => 8,  38 => 7,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "partials/home/product_list.twig", "/home/bafredoc/new.bafredo.com/application/views/partials/home/product_list.twig");
    }
}
