<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* cart.twig */
class __TwigTemplate_01963d79c047f79e0f5b4ae4b7481244e96344c3ad4d76e37506e2da8221e8a8 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/front.twig", "cart.twig", 1);
        $this->blocks = [
            'styles' => [$this, 'block_styles'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "layouts/front.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_styles($context, array $blocks = [])
    {
        // line 3
        echo "\t<style>
\t\t.bodyFrame .pc {
\t\t\tpadding: 0;
\t\t\tpadding-top: 0px;
\t\t\twidth: 1200px;
\t\t\tmargin: 0 auto;
\t\t\tpadding-top: 20px;
\t\t}
\t\t.bodyFrame .pc .lineFrame {
\t\t\twidth: 1200px;
\t\t\tmin-height: 40px;
\t\t\tposition: relative;
\t\t}
\t\t.bodyFrame .pc .shoppingNavFrame {
\t\t\twidth: 100%;
\t\t\theight: 89px;
\t\t\tposition: relative;
\t\t}
\t\t.bodyFrame .pc .shoppingNavFrame b {
\t\t\tdisplay: block;
\t\t\tposition: absolute;
\t\t\tfont-size: 30px;
\t\t\tcolor: #0f054a;;
\t\t\ttop: 35px;
\t\t}
\t\t.bodyFrame .pc .shoppingNavFrame ul {
\t\t\tposition: absolute;
\t\t\ttop: 27px;
\t\t\tright: 0;
\t\t}
\t\t.bodyFrame .pc .shoppingNavFrame ul .select {
\t\t\tborder-bottom: 4px solid #ED6A00;
\t\t\tcolor: #ED6A00;
\t\t}
\t\t.bodyFrame .pc .shoppingNavFrame ul .select {
\t\t\tcolor: #ED6A00;
\t\t}
\t\t.bodyFrame .pc .shoppingNavFrame ul li {
\t\t\tcolor: #707070;
\t\t\tfont-size: 18px;
\t\t\tfont-weight: bold;
\t\t\twidth: 166px;
\t\t\tfloat: left;
\t\t\tmargin-left: 20px;
\t\t\tborder-bottom: 4px solid #A2A2A2;
\t\t\tline-height: 30px;
\t\t\ttext-align: center;
\t\t}
\t\t.bodyFrame .pc .shoppingNavFrame ul li {
\t\t\tcolor: #707070;
\t\t\tfont-size: 18px;
\t\t\tfont-weight: bold;
\t\t\tline-height: 30px;
\t\t\ttext-align: center;
\t\t}
\t\t.bodyFrame .pc .lineFrame {
\t\t\twidth: 1200px;
\t\t\tmin-height: 40px;
\t\t\tposition: relative;
\t\t}
\t\t.cart-table {
\t\t\tborder-bottom: 2px solid #ddd;
\t\t}
\t\t.cart-table th, td {
\t\t\tcolor: #535353;
\t\t\tfont-size: 18px;
\t\t}
\t\t.cart-table td:last-child,
\t\t.cart-table th:last-child {
\t\t\ttext-align: right;
\t\t}
\t\t.cart-footer {
\t\t\tfloat: right;
\t\t}
\t\t.cart-footer td {
\t\t\tpadding-left: 100px;
\t\t\tpadding-bottom: 10px;
\t\t\tcolor: #535353;
\t\t\tfont-size: 18px;
\t\t}
\t\t.cart-footer .btn-contine {
\t\t\ttext-align: right;
\t\t\tmargin-top: 20px;
\t\t}
\t\t.cart-footer .btn-contine button {
\t\t\twidth: 250px;
\t\t}
\t\t.cart-table img {
\t\t\twidth: 94px;
\t\t\theight: 63px;
\t\t\tpadding: 0;
\t\t\tmargin: 0;
\t\t\tborder: none;
\t\t\tborder-radius: 0;
\t\t}
\t\t.cart-table .img-thumbnail {
\t\t\tdisplay: inline-block;
\t\t\tmax-width: 100%;
\t\t\theight: auto;
\t\t\tpadding: 4px;
\t\t\tline-height: 1.42857143;
\t\t\tbackground-color: #fff;
\t\t\tborder: 1px solid #ddd;
\t\t\tborder-radius: 4px;
\t\t\t-webkit-transition: all .2s ease-in-out;
\t\t\t-o-transition: all .2s ease-in-out;
\t\t\ttransition: all .2s ease-in-out;
\t\t\tfloat: left;
\t\t\tmargin-right: 10px;
\t\t}
\t\t.btn-confirm {
\t\t\tdisplay: block;
\t\t\twidth: 250px;
\t\t\theight: 49px;
\t\t\tline-height: 49px;
\t\t\tbackground: #1d8229;
\t\t\tborder: solid 1px #1d8229;
\t\t\tcolor: #FFFFFF;
\t\t\tfloat: right;
\t\t\tfont-size: 20px;
\t\t\ttext-align: center;
\t\t\tfont-weight: bold;
\t\t\tcursor: pointer;
\t\t}
\t\t.input-group {
\t\t\tposition: relative;
\t\t\tdisplay: flex;
\t\t\tborder-collapse: separate;
\t\t\tjustify-content: center;
\t\t}
\t\t.plus-minus-input {
\t\t\t-webkit-align-items: center;
\t\t\t-ms-flex-align: center;
\t\t\talign-items: center;
\t\t\tmargin-top: -9px;
\t\t}
\t\t.plus-minus-input .input-group-field {
\t\t\ttext-align: center;
\t\t\tmargin-left: 0.5rem;
\t\t\tmargin-right: 0.5rem;
\t\t\tpadding: 1rem;
\t\t}
\t\t.plus-minus-input .input-group-field::-webkit-inner-spin-button,
\t\t.plus-minus-input .input-group-field ::-webkit-outer-spin-button {
\t\t\t-webkit-appearance: none;
\t\t\tappearance: none;
\t\t}
\t\t.plus-minus-input .input-group-button .circle {
\t\t\tborder-radius: 50%;
\t\t\tpadding: 0.25em 0.8em;
\t\t}
\t\t.item-quantity-count {
\t\t\twidth: 112px;
\t\t}
\t\t.item-quantity-count input {
\t\t\ttext-align: center;
\t\t}
\t\ttable td.total-price {
\t\t\twidth: 137px;
\t\t}

\t\t/* The container */
\t\t.container-checkbox {
\t\t\tdisplay: block;
\t\t\tposition: relative;
\t\t\tpadding-left: 35px;
\t\t\tmargin-bottom: 22px;
\t\t\tcursor: pointer;
\t\t\tfont-size: 22px;
\t\t\t-webkit-user-select: none;
\t\t\t-moz-user-select: none;
\t\t\t-ms-user-select: none;
\t\t\tuser-select: none;
\t\t}

\t\t/* Hide the browser's default checkbox */
\t\t.container-checkbox input {
\t\t\tposition: absolute;
\t\t\topacity: 0;
\t\t\tcursor: pointer;
\t\t\theight: 0;
\t\t\twidth: 0;
\t\t}

\t\t/* Create a custom checkbox */
\t\t.checkmark {
\t\t\tposition: absolute;
\t\t\ttop: 0;
\t\t\tleft: 0;
\t\t\theight: 25px;
\t\t\twidth: 25px;
\t\t\tbackground-color: #ffffff;
\t\t\tborder: solid 1px #bbb;
\t\t}

\t\t/* On mouse-over, add a grey background color */
\t\t.container-checkbox:hover input ~ .checkmark {
\t\t\tbackground-color: #f2f2f2;
\t\t}

\t\t/* When the checkbox is checked, add a blue background */
\t\t.container-checkbox input:checked ~ .checkmark {
\t\t\tbackground-color: #1d8229;
\t\t}

\t\t/* Create the checkmark/indicator (hidden when not checked) */
\t\t.checkmark:after {
\t\t\tcontent: \"\";
\t\t\tposition: absolute;
\t\t\tdisplay: none;
\t\t}

\t\t/* Show the checkmark when checked */
\t\t.container-checkbox input:checked ~ .checkmark:after {
\t\t\tdisplay: block;
\t\t}

\t\t/* Style the checkmark/indicator */
\t\t.container-checkbox .checkmark:after {
\t\t\tleft: 9px;
\t\t\ttop: 5px;
\t\t\twidth: 5px;
\t\t\theight: 10px;
\t\t\tborder: solid white;
\t\t\tborder-width: 0 3px 3px 0;
\t\t\t-webkit-transform: rotate(45deg);
\t\t\t-ms-transform: rotate(45deg);
\t\t\ttransform: rotate(45deg);
\t\t}
\t</style>
";
    }

    // line 234
    public function block_content($context, array $blocks = [])
    {
        // line 235
        echo "\t<div class=\"container-fluid bodyFrame\">
\t\t<div class=\"row pc checkoutApp\">
\t\t\t<div class=\"lineFrame\">
\t\t\t\t<ul class=\"breadcrumb\">
\t\t\t\t\t<li><a href=\"";
        // line 239
        echo twig_escape_filter($this->env, base_url("/"), "html", null, true);
        echo "\"><i class=\"fa fa-home\"></i></a></li>
\t\t\t\t\t<li><a href=\"";
        // line 240
        echo twig_escape_filter($this->env, base_url("account"), "html", null, true);
        echo "\">Account</a></li>
\t\t\t\t</ul>
\t\t\t</div>
\t\t\t<div class=\"clear\"></div>
\t\t\t<div class=\"lineFrame\">
\t\t\t\t<div class=\"cartListFrame\">
\t\t\t\t\t<div class=\"shoppingNavFrame\">
\t\t\t\t\t\t<b>Shopping Cart</b>
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t<li class=\"select\">1. Shopping Cart</li>
\t\t\t\t\t\t\t<li>2. Check Out</li>
\t\t\t\t\t\t\t<li>3. Confirm Order</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t\t<table class=\"table cart-table\">
\t\t\t\t\t\t<thead>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<th class=\"text-left\">
\t\t\t\t\t\t\t\t<label class=\"container-checkbox\">
\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" v-model=\"allCartItemOptionSelected\" v-on:click=\"checkAllCartItems\">
\t\t\t\t\t\t\t\t\t<span class=\"checkmark\"></span>
\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t</th>
\t\t\t\t\t\t\t<th class=\"text-left\">Product Name</th>
\t\t\t\t\t\t\t<th class=\"text-center\">Price</th>
\t\t\t\t\t\t\t<th class=\"text-center\">Quantity</th>
\t\t\t\t\t\t\t<th class=\"text-center\">Action</th>
\t\t\t\t\t\t\t<th class=\"text-center\">Total</th>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</thead>
\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t<tr v-for=\"item in cart\">
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<label class=\"container-checkbox\">
\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" v-model=\"selectedCartItems\" :value=\"item.id\" v-on:click=\"pushSelectedToCheckoutCart(item, this)\">
\t\t\t\t\t\t\t\t\t<span class=\"checkmark\"></span>
\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<a v-bind:title=\"item.name\" v-bind:href=\"productDetail(item.slug)\"><img v-bind:src=\"productImage(item.image)\" v-bind:alt=\"item.name\" v-bind:title=\"item.name\" class=\"img-thumbnail\"></a>
\t\t\t\t\t\t\t\t<a v-bind:title=\"item.name\" v-bind:href=\"productDetail(item.slug)\" v-text=\"item.name\"></a>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td v-text=\"item.currency +' '+ item.price\"></td>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<div class=\"input-group plus-minus-input\">
\t\t\t\t\t\t\t\t\t<div class=\"widgets-numberpicker\">
\t\t\t\t\t\t\t\t\t\t<div class=\"widgets-numberpicker-decrement\" v-on:click=\"cartItemQuantityDecrement(item)\"></div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"input-group-field item-quantity-count\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control\" v-model=\"item.quantity\" v-on:keypress=\"onlyNumber\" maxlength=\"9\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"widgets-numberpicker\">
\t\t\t\t\t\t\t\t\t\t<div class=\"widgets-numberpicker-increment\" v-on:click=\"cartItemQuantityIncrement(item)\"></div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<button class=\"btn btn-danger\" onclick=\"return confirm('Are you sure?')\" v-on:click=\"removeFromCart(item)\">Delete</button>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td class=\"total-price\" v-text=\"item.currency +' '+  Math.round((item.price * item.quantity))\"></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</tbody>
\t\t\t\t\t</table>
\t\t\t\t\t<div class=\"cart-footer\">
\t\t\t\t\t\t<table>
\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td>Subtotal</td>
\t\t\t\t\t\t\t\t<td><span v-text=\"subtotal\"></span></td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td>Tax</td>
\t\t\t\t\t\t\t\t<td><span v-text=\"tax\"></span></td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td>Total</td>
\t\t\t\t\t\t\t\t<td><span v-text=\"total\"></span></td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t</table>
\t\t\t\t\t\t<div class=\"btn-contine\">
\t\t\t\t\t\t\t<button class=\"btn-confirm\" v-on:click=\"cartCheckout()\" v-bind:disabled=\"selectedCartItems.length == 0\">Continue</button>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "cart.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  290 => 240,  286 => 239,  280 => 235,  277 => 234,  43 => 3,  40 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "cart.twig", "/home/bafredoc/new.bafredo.com/application/views/cart.twig");
    }
}
