<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* layouts/front.twig */
class __TwigTemplate_73b2ea7271be287a357bc28cc5b2854c269ed90d0b1255ba9e8958b1b91a6e4b extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
            'styles' => [$this, 'block_styles'],
            'content' => [$this, 'block_content'],
            'scripts' => [$this, 'block_scripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>

    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

    <title>Bafredo</title>

    <script type=\"text/javascript\">
        var webPath     = '";
        // line 11
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "';
        var mobileJSUrl = \"";
        // line 12
        echo asset("front/js/mobile.js");
        echo "\";
        var webImgPath  = '";
        // line 13
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "';
        var serverTime  = '";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute(twig_date_converter($this->env), "timestamp", []), "html", null, true);
        echo "';
        var currentPage = '";
        // line 15
        echo twig_escape_filter($this->env, get_segment(2), "html", null, true);
        echo "';
    </script>

    <script src=\"";
        // line 18
        echo asset("front/js/jquery-2.1.1.min.js");
        echo "\" type=\"text/javascript\"></script>

    <script src=\"";
        // line 20
        echo asset("plugins/typeahead/js/jquery.xdomainrequest.min.js");
        echo "\"></script>
    <script src=\"";
        // line 21
        echo asset("plugins/typeahead/js/typeahead.bundle.js");
        echo "\"></script>
    <link href=\"";
        // line 22
        echo asset("plugins/typeahead/css/normalize.min.css");
        echo "\" rel=\"stylesheet\" media=\"screen\" />
    <link href=\"";
        // line 23
        echo asset("plugins/typeahead/css/main.css");
        echo "\" rel=\"stylesheet\" media=\"screen\" />

    <script src=\"";
        // line 25
        echo asset("front/js/bootstrap.min.js");
        echo "\" type=\"text/javascript\"></script>
    <script src=\"";
        // line 26
        echo asset("front/js/hammer.min.js");
        echo "\" type=\"text/javascript\"></script>
    <script src=\"";
        // line 27
        echo asset("front/js/iscroll.js");
        echo "\" type=\"text/javascript\"></script>

    <link href=\"";
        // line 29
        echo asset("front/css/bootstrap.min.3.4.css");
        echo "\" rel=\"stylesheet\" media=\"screen\" />
    <link href=\"";
        // line 30
        echo asset("front/css/bootstrap.min.css");
        echo "\" rel=\"stylesheet\" media=\"screen\" />
    <link href=\"";
        // line 31
        echo asset("front/css/font-awesome.min.css");
        echo "\" rel=\"stylesheet\" type=\"text/css\" />
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Condensed|Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
    <link href=\"";
        // line 34
        echo asset("front/css/stylesheet.css");
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 35
        echo asset("front/css/iconfont.css");
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 36
        echo asset("front/css/owl.carousel.css");
        echo "\" type=\"text/css\" rel=\"stylesheet\" media=\"screen\" />
    <link href=\"";
        // line 37
        echo asset("front/image/logo/icon-100x100.png");
        echo "\" rel=\"icon\" />

    <script src=\"";
        // line 39
        echo asset("front/js/common.js");
        echo "\" type=\"text/javascript\"></script>
    <script src=\"";
        // line 40
        echo asset("front/js/owl.carousel.min.js");
        echo "\" type=\"text/javascript\"></script>

    <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','../www.google-analytics.com/analytics.js','ga');

        ga('create', '', 'auto');
        ga('send', 'pageview');
    </script>

    <!--head css js-->
    <link href=\"";
        // line 53
        echo asset("front/css/head.css");
        echo "\" rel=\"stylesheet\">
    <script src=\"";
        // line 54
        echo asset("front/js/config.js");
        echo "\" type=\"text/javascript\"></script>
    <script src=\"";
        // line 55
        echo asset("front/js/cart.js");
        echo "\" type=\"text/javascript\"></script>
    <script src=\"";
        // line 56
        echo asset("front/js/head.js");
        echo "\" type=\"text/javascript\"></script>
    <script src=\"";
        // line 57
        echo asset("front/js/djs.js");
        echo "\" type=\"text/javascript\"></script>
    <script src=\"";
        // line 58
        echo asset("front/js/pbl.js");
        echo "\" type=\"text/javascript\"></script>
    <script src=\"";
        // line 59
        echo asset("front/js/bigeye.js");
        echo "\" type=\"text/javascript\"></script>
    ";
        // line 61
        echo "    <script src=\"";
        echo asset("front/js/mobile.js");
        echo "\" type=\"text/javascript\"></script>
    <script src=\"";
        // line 62
        echo asset("front/js/pc.js");
        echo "\" type=\"text/javascript\"></script>
    <!-- Facebook Pixel Code  Adair - 2018.01.10  Start -->
    <!-- Facebook Pixel Code -->
    <script>
        !function(f,b,e,v,n,t,s)

        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?

            n.callMethod.apply(n,arguments):n.queue.push(arguments)};

            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';

            n.queue=[];t=b.createElement(e);t.async=!0;

            t.src=v;s=b.getElementsByTagName(e)[0];

            s.parentNode.insertBefore(t,s)}(window,document,'script',

            '../connect.facebook.net/en_US/fbevents.js');


        fbq('init', '');

        fbq('track', 'ViewContent');

    </script>
    <noscript>
        <img height=\"1\" width=\"1\" src=\"https://www.facebook.com/tr?id=517401871764527&amp;ev=PageView&amp;noscript=1\"/>
    </noscript>
    <!-- End Facebook Pixel Code -->
    <!-- Facebook Pixel Code  Adair - 2018.01.10  End -->

    <script type=\"text/javascript\">
        \$(document).ready(function(){
            var pageKey = \"home\";
            \$.pc({type:\"init\",page:pageKey});
        });
    </script>

    <link rel=\"stylesheet\" href=\"";
        // line 101
        echo asset("css/app.css");
        echo "\">

    <style type=\"text/css\">
        .headFrame .small {
            height: 80px;
        }
        .headFrame .pc .fastCategory .logow {
            margin-bottom: 50px;
            margin-top: 15px;
            height: 65px;
            padding: 7px 0 0 5px;
            width: 257px;
        }
        .logow .logo {
            width: 257px;
            display: block;
            max-width: 100%;
            height: auto;
        }
        .small .logow {
            margin-top: 0px !important;
        }
        .headFrame .pc .left {
            margin-top: 15px;
        }
        .headFrame .small .left {
            margin-top: 0px;
        }
        .headFrame .pc .left .searchFrame {
            width: 600px;
            margin-left: 35px;
        }
        .headFrame .pc .left .search {
            width: 100%;
        }
        .headFrame .pc .fastCategory,
        .headFrame .pc {
            background: #1d8229;
        }
        .bodyFrame .pc #column-left .categoryFrame {
            border: 3px solid #166420;
            background: #1d8229;
        }
        .bodyFrame .pc #column-left .categoryFrame .select,
        .headFrame .pc .fastCategory .list .select {
            background: #0f054a;
        }
        .bodyFrame .pc #column-left .categoryFrame .select a,
        .headFrame .pc .fastCategory .list .select a {
            color: #fff;
        }
        .bodyFrame .pc .productTitle b {
            color: #1d8229;
        }
        .bodyFrame .pc .productList li .btns button {
            background: #1d8229;
        }
        .bodyFrame .pc .productList li .btns b {
            color: #0f054a;
        }
        footer .pc .webMap .logo {
            padding: 10px 0 0 12px;
            width: 270px;
        }
        .header-top-thick {
            color: #fff;
            background: #0f054a;
            padding: 7px 37px;
        }
        .header-top-thick li {
            float: left;
            margin: 0px 10px;
            text-transform: uppercase;
        }
        .header-top-thick li a {
            color: #fff;
        }
        .header-top-thick li a:hover {
            color: #1d8229;
        }
        .float-left {
            float: left;
        }
        .float-right {
            float: right;
        }

        .headFrame .pc .right .shoppingCart .cartList .info {
            padding-bottom: 20px;
        }
        .headFrame .pc .right .shoppingCart .cartList .info .showCartBtn {
            background: #1d8229;
            width: 108px;
            height: 30px;
            right: 8px;
            top: 12px;
            border-radius: 5px;
            display: block;
            position: absolute;
            text-align: center;
            line-height: 30px;
            color: #FFFFFF;
            font-size: 12px;
            font-weight: bold;
         }
        [v-cloak] {
            display: none;
        }
        .add-to-cart-notif {
            color: #fff;
            background-color: #0f054a;
            border-color: #0f054a;
            position: absolute;
            right: 0px;
            top: 37px;
            z-index: 91;
            padding: 17px 77px;
            position: fixed;
        }
        .green-line {
            right: 0px;
            top: 36px;
            z-index: 91;
            position: fixed;
            background: #24df24;
            width: 13px;
            height: 58px;
        }
        .tt-menu {
            width: 108%;
            background: #fff;
            position: absolute;
            top: 100%;
            left: -43px !important;
            z-index: 100;
            display: block;
            margin-top: 3px;
            border: solid 2px #1d8229;
        }
        .ProfileCard:hover, .ProfileCard.is-active {
            color: #fff;
            background: #0f054a;
        }
        .ProfileCard-stat {
            line-height: 8px;
        }
        .bodyFrame .pc .productList li {
            height: 293px;
        }
        button:disabled,
        button[disabled]{
            border: 1px solid #999999;
            background-color: #cccccc;
            color: #666666;

        }
        .img-responsive {
            height: 70px;
        }
    </style>
    ";
        // line 261
        $this->displayBlock('styles', $context, $blocks);
        // line 262
        echo "</head>

<body>
<div id=\"app\">
    <div v-cloak v-show=\"addToCartNotFlag\">
        <div class=\"alert add-to-cart-notif\">\${ notificationMsg }</div>
        <div class=\"green-line\"></div>
    </div>

    ";
        // line 272
        echo "        ";
        // line 273
        echo "            ";
        // line 274
        echo "            ";
        // line 275
        echo "                ";
        // line 276
        echo "                    ";
        // line 277
        echo "                    ";
        // line 278
        echo "                    ";
        // line 279
        echo "                ";
        // line 280
        echo "            ";
        // line 281
        echo "        ";
        // line 282
        echo "    ";
        // line 283
        echo "    <header class=\"headFrame\">
        <div class=\"container-fluid\">
            <!--<a target=\"_blank\" href='https://www.dfrobot.com/blog-810.html?tracking=5a3117d2329ab'><img src='http://image.dfrobot.com/image/banner/ChristmasSaleTop.png' style='width:100%'/></a>-->
            <div class=\"pc row hidden-xs\">
                <div class=\"con\">
                    <div class=\"left\">
                        <div class=\"logo\">
                            <a title=\"Bafredo\" href=\"";
        // line 290
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "\"><img src=\"";
        echo asset("front/image/logo.png");
        echo "\" title=\"Bafredo\" alt=\"Bafredo\" class=\"img-responsive\" /></a>

                        </div>
                        <div class=\"searchFrame\">
                            <form action=\"";
        // line 294
        echo twig_escape_filter($this->env, base_url("home/search"), "html", null, true);
        echo "\" name=\"search\">
                                <div class=\"search\">
                                  <span>
                                  <i class=\"iconfont icon-search\"></i>
                                  </span>
                                  <span>
                                      <input class=\"Typeahead-hint\" type=\"text\" tabindex=\"-1\" readonly>
                                      <input class=\"searchInput\" id=\"typeahead\" type=\"text\" name=\"q\" placeholder=\"Search...\"/>
                                      <input type=\"hidden\" name=\"slug\" id=\"slug\"/>
                                      <img class=\"Typeahead-spinner\" src=\"";
        // line 303
        echo asset("plugins/typeahead/spinner.gif");
        echo "\">
                                  </span>
                                  <span>
                                  <i class=\"fa fa-remove\"></i>
                                  </span>
                                </div>
                            </form>
                            ";
        // line 332
        echo "
                            <script id=\"result-template\" type=\"text/x-handlebars-template\">
                                <div class=\"ProfileCard u-cf\">
                                    <img class=\"ProfileCard-avatar\" src=\"{{thumbnail}}\">

                                    <div class=\"ProfileCard-details\">
                                        <div class=\"ProfileCard-realName\">{{name}}</div>
                                        <div class=\"ProfileCard-screenName\">@{{brand}}</div>
                                        <div class=\"ProfileCard-description\">{{description}}</div>
                                    </div>

                                    <div class=\"ProfileCard-stats\">
                                        <!--<div class=\"ProfileCard-stat\"><span class=\"ProfileCard-stat-label\">Tweets:</span> {{statuses_count}}</div>-->
                                        <div class=\"ProfileCard-stat\"><span class=\"ProfileCard-stat-label\">SKU:</span> {{sku}}</div>
                                        <div class=\"ProfileCard-stat\"><span class=\"ProfileCard-stat-label\">Price:</span> {{currency}} {{price}}</div>
                                    </div>
                                </div>
                            </script>

                            <script id=\"empty-template\" type=\"text/x-handlebars-template\">
                                <div class=\"EmptyMessage\">Your search turned up 0 results. This most likely means the backend is down, yikes!</div>
                            </script>
                            ";
        echo "
                        </div>
                        <div class=\"navigate\">
                            <a title=\"HOME\" href=\"";
        // line 335
        echo twig_escape_filter($this->env, base_url("/"), "html", null, true);
        echo "\">HOME</a>
                            ";
        // line 337
        echo "                            ";
        // line 338
        echo "                            <a title=\"BLOG\" href=\"";
        echo twig_escape_filter($this->env, base_url("blog"), "html", null, true);
        echo "\">BLOG</a>
                        </div>
                        <div class=\"currency\">
                            <div class=\"pull-left\">
                                ";
        // line 343
        echo "                                ";
        // line 344
        echo "                                ";
        // line 345
        echo "                                ";
        // line 346
        echo "                                ";
        // line 347
        echo "                                ";
        // line 348
        echo "                                ";
        // line 349
        echo "                                ";
        // line 350
        echo "                                ";
        // line 351
        echo "                                ";
        // line 352
        echo "                                ";
        // line 353
        echo "                                ";
        // line 354
        echo "                                ";
        // line 355
        echo "                                ";
        // line 356
        echo "                                ";
        // line 357
        echo "                            </div>
                        </div>
                    </div>
                    <div class=\"right\">
                        <div class=\"cartFrame\">
                            <div class=\"shoppingCart hidden-xs\">
                                ";
        // line 363
        echo twig_include($this->env, $context, "partials/cart/homepage_header_button.twig");
        echo "
                                <div class=\"cartListFrame\">
                                    <div class=\"cartList\">
                                        <div class=\"mask\"></div>
                                        <div v-if=\"cart.length > 0\">
                                            <div class=\"list\">
                                                <ul>
                                                    <li v-for=\"product in cart\">
                                                        <div class=\"img\">
                                                            <a :href=\"productDetail(product.slug)\">
                                                                <img :src=\"productImage(product.image)\" :alt=\"product.name\" :title=\"product.name\">
                                                            </a>
                                                        </div>
                                                        <div class=\"productName\">
                                                            <a :href=\"productDetail(product.slug)\">\${ product.name }</a>
                                                        </div>
                                                        <div class=\"price\">
                                                            <span class=\"l\"><b>\${ product.currency +' '+ product.price }</b>  x 1</span>
                                                            <span class=\"r\">
                                                            <button class=\"removeBtn\" v-on:click=\"removeFromCart(product)\">Remove</button>
                                                        </span>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <div class=\"iScrollVerticalScrollbar iScrollLoneScrollbar\" style=\"overflow: hidden; pointer-events: none;\">
                                                    <div class=\"iScrollIndicator\" style=\"transition-duration: 0ms; display: none; height: 72px; transform: translate(0px) translateZ(0px); transition-timing-function: cubic-bezier(0.1, 0.57, 0.1, 1);\"></div>
                                                </div>
                                                <div class=\"iScrollVerticalScrollbar iScrollLoneScrollbar\" style=\"overflow: hidden; pointer-events: none;\">
                                                    <div class=\"iScrollIndicator\" style=\"transition-duration: 0ms; display: none; height: 72px; transform: translate(0px) translateZ(0px); transition-timing-function: cubic-bezier(0.1, 0.57, 0.1, 1);\"></div>
                                                </div>
                                            </div>
                                            <div class=\"info\">
                                                <div class=\"totNum\">
                                                    <span>\${ cart.length }</span> items
                                                </div>
                                                <a class=\"showCartBtn\" href=\"";
        // line 398
        echo twig_escape_filter($this->env, base_url("cart"), "html", null, true);
        echo "\">View my cart</a>
                                                <div class=\"clear\"></div>
                                            </div>
                                        </div>
                                        <div v-else class=\"empty\">
                                            <p class=\"text-center\">Your shopping cart is empty!</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=\"login\">
                            ";
        // line 410
        if ( !authCheck("user")) {
            // line 411
            echo "                                <span class=\"loginInfo savebackurl\" data-login=\"false\">
                                    <a title=\"account login\" class=\"loginBtns\" href=\"";
            // line 412
            echo twig_escape_filter($this->env, base_url("login"), "html", null, true);
            echo "\">
                                        <i class=\"iconfont icon-use\"></i>LOGIN/SIGNUP
                                    </a>
                                </span>
                            ";
        } else {
            // line 417
            echo "                                <div class=\"username\">
                                    <span class=\"loginInfo savebackurl\" data-login=\"false\">
                                        <a title=\"profile\" class=\"loginBtns\" href=\"";
            // line 419
            echo twig_escape_filter($this->env, base_url("account"), "html", null, true);
            echo "\">
                                            <i class=\"iconfont icon-use\"></i>";
            // line 420
            echo twig_escape_filter($this->env, $this->getAttribute(getAuthUser("user"), "name", []), "html", null, true);
            echo "
                                        </a>
                                    </span>
                                    <div class=\"user-info-box\">
                                        <div class=\"mask\"></div>
                                        <div class=\"head\">
                                            <div class=\"headImg\"><img src=\"";
            // line 426
            echo twig_escape_filter($this->env, ((twig_test_empty($this->getAttribute(($context["user"] ?? null), "getUserImg", [], "method"))) ? (base_url("assets/front/image/profile.png")) : ((base_url("assets/front/image/users/") . $this->getAttribute(($context["user"] ?? null), "getUserImg", [], "method")))), "html", null, true);
            echo "  \" alit=\"dp\"></div>
                                            <div class=\"userName\">
                                                <b>";
            // line 428
            echo twig_escape_filter($this->env, $this->getAttribute(getAuthUser("user"), "name", []), "html", null, true);
            echo "</b>
                                                <div class=\"score-reward\">Store Credit:<i>0.00</i></div>
                                                <div class=\"score-reward\">Reward Points:<i>0.00</i></div>
                                            </div>
                                        </div>
                                        <ul>
                                            <li><a href=\"";
            // line 434
            echo twig_escape_filter($this->env, base_url("account"), "html", null, true);
            echo "\">My Account</a></li>
                                            <li><a href=\"";
            // line 435
            echo twig_escape_filter($this->env, base_url("account/order_history"), "html", null, true);
            echo "\">Order History</a></li>
                                            <li><a href=\"";
            // line 436
            echo twig_escape_filter($this->env, base_url("user/logout"), "html", null, true);
            echo "\">Logout</a></li>
                                        </ul>
                                    </div>
                                </div>
                            ";
        }
        // line 441
        echo "                            <span class=\"wishlist\">
                                <a title=\"wishlist\" class=\"loginBtns\" href=\"#\">
                                    <i class=\"iconfont icon-hart\"></i><b class=\"wishlist\">Wishlist</b>
                                </a>
                            </span>
                        </div>
                    </div>

                    <!-- When mouse hover on logo a dropdown menu appear -->
                    ";
        // line 450
        if ( !twig_test_empty(get_segment(1))) {
            // line 451
            echo "                    <span><i class=\"iconfont icon-downarrow\" style=\"position: absolute; left: 216px; top: 43px; color: rgb(255, 255, 255);\"></i></span>
                    ";
        }
        // line 453
        echo "                    <div class=\"fastCategory\">
                        <div class=\"logow\">

                            <a title=\"home\" href=\"/\"><img class=\"img-responsive\" src=\"";
        // line 456
        echo asset("front/image/logo.png");
        echo "\" alt=\"logo\" /></a>

                        </div>

                        ";
        // line 460
        echo twig_include($this->env, $context, "partials/home/menus.twig");
        echo "

                    </div>


                </div>
            </div>

            <!-- Mobile version -->
            <div class=\"mobile row visible-xs\" style=\"top:0px;\">
                <div class=\"navFrame\">
                    <div>
                        <div class=\"login\">
                            ";
        // line 473
        if ( !authCheck("user")) {
            // line 474
            echo "                                <a title=\"login\" class=\"login_user\" href=\"";
            echo twig_escape_filter($this->env, base_url("login"), "html", null, true);
            echo "\">
                                    <i class=\"iconfont icon-use\"></i>LOGIN/SIGNUP
                                </a>
                            ";
        } else {
            // line 478
            echo "                                <a title=\"login\" class=\"login_user\" href=\"";
            echo twig_escape_filter($this->env, base_url("account"), "html", null, true);
            echo "\">
                                    <i class=\"iconfont icon-use\"></i>";
            // line 479
            echo twig_escape_filter($this->env, $this->getAttribute(getAuthUser("user"), "name", []), "html", null, true);
            echo "
                                </a>
                            ";
        }
        // line 482
        echo "                            <a rel=\"nofollow\" href=\"javascript:;\" class=\"closeBtn\"><i class=\"fa fa-remove\"></i></a>
                        </div>
                        <div class=\"search\">
                            <i class=\"fa fa-search\"></i><input class=\"searchInput\" value=\"\" type=\"text\" placeholder=\"Enter Search Key\"/>
                        </div>
                        <div class=\"sf\">
                            <ul class=\"nf\">
                                <li>
                                    <a title=\"CATEGORY\" class=\"first category\" href=\"javascript:;\">CATEGORY<i class=\"fa fa-chevron-down\"></i></a>
                                    <ul class=\"sn\">
                                    </ul>
                                </li>
                                <li><a title=\"HOME\" class=\"first\" href=\"#\">HOME</a></li>
                                <li><a title=\"COMMUNITY\" class=\"first\" href=\"#\">COMMUNITY</a></li>
                                <li><a title=\"WIKI\" class=\"first\" href=\"#\">WIKI</a></li>
                                <li><a title=\"BLOG\" class=\"first\" href=\"#\">BLOG</a></li>
                                <li>
                                    <a title=\"CURRENCY\" data-type=\"off\" class=\"first mobile_cur\" href=\"javascript:;\">CURRENCY<i class=\"fa fa-chevron-down\"></i></a>
                                    <form id=\"form-currency2\" enctype=\"multipart/form-data\" method=\"post\" action=\"#\">
                                        <input type=\"hidden\" class=\"c_code\" value=\"\" name=\"code\">
                                        <ul class=\"cur_sub\">
                                        </ul>
                                    </form>
                                </li>
                                ";
        // line 506
        if (authCheck("user")) {
            // line 507
            echo "                                    <li class=\"accountNav\" >
                                        <a data-type=\"off\" class=\"first mobile_account\" href=\"javascript:;\">MY ACCOUNT<i class=\"fa fa-chevron-down\"></i></a>
                                        <ul class=\"account_sub\">
                                            <li><a title=\"Edit Account\" href=\"#\">Edit Account</a></li>
                                            <li><a title=\"Password\" href=\"#\">Password</a></li>
                                            <li><a title=\"Address book\" href=\"#\">Address book</a></li>
                                            <li><a title=\"Wish List\" href=\"#\">Wish List</a></li>
                                            <li><a title=\"Order History\" href=\"#\">Order History</a></li>
                                            <li><a title=\"Returns\" href=\"#\">Returns</a></li>
                                            <li><a title=\"Logout\" href=\"";
            // line 516
            echo twig_escape_filter($this->env, base_url("user/logout"), "html", null, true);
            echo "\">Logout</a></li>
                                        </ul>
                                    </li>
                                ";
        }
        // line 520
        echo "                            </ul>
                        </div>
                    </div>
                </div>
                <div class=\"l navBtn\">
                    <i class=\"fa fa-align-justify\"></i>
                </div>
                <div class=\"r\">
                    <div class=\"visible-xs\">
                        ";
        // line 529
        echo twig_include($this->env, $context, "partials/cart/homepage_header_button.twig");
        echo "
                    </div>
                </div>
                <div class=\"logo\">
                    <a title=\"home\" href=\"#\"><img src=\"";
        // line 533
        echo asset("front/image/logo.png");
        echo "\" title=\"Bafredo\" alt=\"Bafredo\" class=\"img-responsive\" /></a>
                </div>
            </div>
        </div>
    </header>

    <div class=\"container-fluid bodyFrame\">
        ";
        // line 540
        $this->displayBlock('content', $context, $blocks);
        // line 541
        echo "    </div>

    <div id=\"public_footer\">
        <footer>
            <div class=\"pc hidden-xs\">
                <div class=\"subscribe\">
                    <div class=\"footFrame\">
                        <div class=\"left\">
                            <span>Please sign up for our exclusive offers!</span>
                            <div>
                                <!-- Begin MailChimp Signup Form -->
                                <!--<link href=\"//cdn-images.mailchimp.com/embedcode/slim-10_7.css\" rel=\"stylesheet\" type=\"text/css\">-->
                                <div id=\"mc_embed_signup\">
                                        <div id=\"mc_embed_signup_scroll\" class=\"footer_scroll\">
                                            <input type=\"email\" value=\"\" name=\"EMAIL newsletter_email\" class=\"email\" id=\"newsletter_email\" placeholder=\"Your email address\" required>
                                            <div style=\"position: absolute; left: -5000px;\" aria-hidden=\"true\"><input type=\"text\" name=\"b_e384b3074873a648e7d3237cc_316955a8ff\" tabindex=\"-1\" value=\"\"></div>
                                            <button  name=\"subscribe\" id=\"subscribeBtn\" onclick=\"subscribe_email()\" ><i class=\"iconfont icon-subscribe\"></i></button>
                                        </div>
                                </div>

                            </div>
                        </div>
                        <div class=\"right\">
                            <span>Like us on</span>
                            <p>
                                <a rel=\"nofollow\" href=\"https://www.facebook.com/bafredonics/\" target=\"_blank\"><img style=\"width: 19px;height: auto;margin-top: 8px;\"  src=\"";
        // line 566
        echo asset("front/image/icons/facebook.svg");
        echo "\"></a>
                                <a rel=\"nofollow\" href=\"https://twitter.com/bafredonics\" target=\"_blank\"><img style=\"width: 19px;height: auto;margin-top: 8px;\"  src=\"";
        // line 567
        echo asset("front/image/icons/twitter.png");
        echo "\"></a>
                                <a rel=\"nofollow\" href=\"https://www.instagram.com/bafredonics/\" target=\"_blank\">
                                    <img style=\"width: 19px;height: auto;margin-top: 8px;\" src=\"";
        // line 569
        echo asset("front/image/icons/instagram.png");
        echo "\">
                                </a>
                                <a rel=\"nofollow\" href=\"https://www.youtube.com/channel/UC601Ys2fPPwhkmyhdp9MrhQ?view_as=subscriber\" target=\"_blank\"><img style=\"width: 19px;height: auto;margin-top: 8px;\"  src=\"";
        // line 571
        echo asset("front/image/icons/youtube.png");
        echo "\"></a>
                                <a rel=\"nofollow\" href=\"https://www.linkedin.com/company/bafredo-electronics-limited/\" target=\"_blank\"><img style=\"width: 19px;height: auto;margin-top: 8px;\"  src=\"";
        // line 572
        echo asset("front/image/icons/linkedin.png");
        echo "\"></a>
                            </p>
                        </div>
                        <div class=\"clear\"></div>
                    </div>
                </div>
                <div class=\"webMap\">
                    <div class=\"footFrame\">
                        <div class=\"logo\">
                            <a href=\"";
        // line 581
        echo twig_escape_filter($this->env, base_url("/"), "html", null, true);
        echo "\"><img src=\"";
        echo asset("front/image/logo/PNG/white.png");
        echo "\" alt=\"logo\" /></a>
                        </div>
                        <div class=\"map\">
                            <div class=\"list\">
                                <h5>Customer Service</h5>
                                <ul>
                                    <li><a rel=\"nofollow\" href=\"";
        // line 587
        echo twig_escape_filter($this->env, base_url("page/how-to-buy"), "html", null, true);
        echo "\">How to buy</a></li>
                                    <li><a rel=\"nofollow\" href=\"";
        // line 588
        echo twig_escape_filter($this->env, base_url("page/privacy-policy"), "html", null, true);
        echo "\">Privacy Policy</a></li>
                                    <li><a rel=\"nofollow\" href=\"";
        // line 589
        echo twig_escape_filter($this->env, base_url("page/terms-conditions"), "html", null, true);
        echo "\">Terms &amp; Conditions</a></li>
                                    <li><a rel=\"nofollow\" href=\"";
        // line 590
        echo twig_escape_filter($this->env, base_url("page/faqs"), "html", null, true);
        echo "\">FAQs</a></li>
                                </ul>
                            </div>
                            <div class=\"list\">
                                <h5>My Account</h5>
                                <ul>
                                    <li><a rel=\"nofollow\" href=\"";
        // line 596
        echo twig_escape_filter($this->env, base_url("account"), "html", null, true);
        echo "\">My Orders</a></li>
                                    <li><a rel=\"nofollow\" href=\"";
        // line 597
        echo twig_escape_filter($this->env, base_url("account"), "html", null, true);
        echo "\">My Profile</a></li>
                                </ul>
                            </div>
                            <div class=\"list\">
                                <h5>Company</h5>
                                <ul>
                                    <li><a rel=\"nofollow\" href=\"";
        // line 603
        echo twig_escape_filter($this->env, base_url("page/about-us"), "html", null, true);
        echo "\">About Us</a></li>
                                    <li><a rel=\"nofollow\" href=\"";
        // line 604
        echo twig_escape_filter($this->env, base_url("page/contact-us"), "html", null, true);
        echo "\">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class=\"copyright\">
                            &copy; ";
        // line 609
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " BAFREDO Electronics Limited. All rights reserved.
                        </div>
                    </div>
                </div>
            </div>
            <div class=\"mobile visible-xs\">
                <div class=\"subscribe\">
                    <div class=\"footFrame\">
                        <div class=\"left\">
                            <!--<form action=\"subscribe.php\" method=\"post\">
                              <span>Signup for exclusive offers!</span>
                              <p>
                                  <input value=\"\" type=\"email\" placeholder=\"Your Email Address\"/>
                                  <button type=\"button\" onclick=\"document.forms[0].submit()\">
                                      <i class=\"fa fa-signal\"></i>
                                  </button>
                              </p>
                              </form>-->
                            <!-- Begin MailChimp Signup Form -->
                            <div style=\"padding: 2% 10%;\">
                                <!--<link href=\"//cdn-images.mailchimp.com/embedcode/slim-10_7.css\" rel=\"stylesheet\" type=\"text/css\">-->
                                <div id=\"mc_embed_signup\">
                                    <form action=\"#\" method=\"post\" id=\"mc-embedded-subscribe-form\" name=\"mc-embedded-subscribe-form\" class=\"validate\" target=\"_blank\" novalidate>
                                        <div id=\"mc_embed_signup_scroll\" class=\"footer_scroll\">
                                            <!--<label for=\"mce-EMAIL\">Subscribe to our mailing list</label>-->
                                            <input type=\"email\" value=\"\" name=\"EMAIL\" class=\"email\" id=\"subscribeEmail\" placeholder=\"Your email address\" required>
                                            <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                                            <div style=\"position: absolute; left: -5000px;\" aria-hidden=\"true\"><input type=\"text\" name=\"b_e384b3074873a648e7d3237cc_316955a8ff\" tabindex=\"-1\" value=\"\"></div>
                                            <button type=\"submit\" name=\"subscribe\" id=\"subscribeBtn1\"><i class=\"iconfont icon-subscribe\"></i></button>
                                            <!--<div class=\"clear\"><input type=\"submit\" value=\"Subscribe\" name=\"subscribe\" id=\"mc-embedded-subscribe\" class=\"button\"></div>-->
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class=\"right\">
                            <p class=\"xsRightP\">
                                <span>Like us on</span>
                                <a rel=\"nofollow\" href=\"https://www.facebook.com/bafredonics/\" target=\"_blank\"><i class=\"facebook\"></i></a>
                                <a rel=\"nofollow\" href=\"https://twitter.com/bafredonics\" target=\"_blank\"><i class=\"twitter\"></i></a>
                                <a rel=\"nofollow\" href=\"https://www.instagram.com/bafredonics/\" target=\"_blank\">
                                    <img style=\"width: 19px;height: auto;margin-top: 8px;\" src=\"";
        // line 650
        echo asset("front/image/icons/instagram_bw.png");
        echo "\">
                                </a>
                                <a rel=\"nofollow\" href=\"https://www.youtube.com/channel/UC601Ys2fPPwhkmyhdp9MrhQ?view_as=subscriber\" target=\"_blank\"><i class=\"youtube\"></i></a>
                                <a rel=\"nofollow\" href=\"https://www.linkedin.com/company/bafredo-electronics-limited/\" target=\"_blank\"><i class=\"linkedin\"></i></a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

    </div>
</div>
<script type=\"text/javascript\">

    function validateEmail(\$email) {
        var emailReg = /^([\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4})?\$/;
        return emailReg.test(\$email);
    }
    function subscribe_email()
    {
        if (validateEmail(\$(\"#newsletter_email\").val() || \$(\"#newsletter_email\").val().trim() != \"\")) {
            \$.ajax({
                url: '";
        // line 673
        echo twig_escape_filter($this->env, base_url("home/subscribe"), "html", null, true);
        echo "',
                data: {
                    email: \$('#newsletter_email').val(),
                },
                type: 'post',
                success: function (output) {
                    if (output) {
                        alert(\"Subscribed Successfully\")
                    } else {
                        alert(\"Already Subscribed\")
                    }
                }
            });
        } else {

            alert(\"Email Incorrect\")
        }
    }
    (function(e, a) {
        if(!a.__SV) {
            var b = window;
            try {
                var c, l, i, j = b.location,
                    g = j.hash;
                c = function(a, b) {
                    return(l = a.match(RegExp(b + \"=([^&]*)\"))) ? l[1] : null
                };
                g && c(g, \"state\") && (i = JSON.parse(decodeURIComponent(c(g, \"state\"))), \"mpeditor\" === i.action && (b.sessionStorage.setItem(\"_mpcehash\", g), history.replaceState(i.desiredHash || \"\", e.title, j.pathname + j.search)))
            } catch(m) {}
            var k, h;
            window.mixpanel = a;
            a._i = [];
            a.init = function(b, c, f) {
                function e(b, a) {
                    var c = a.split(\".\");
                    2 == c.length && (b = b[c[0]], a = c[1]);
                    b[a] = function() {
                        b.push([a].concat(Array.prototype.slice.call(arguments,
                            0)))
                    }
                }
                var d = a;
                \"undefined\" !== typeof f ? d = a[f] = [] : f = \"mixpanel\";
                d.people = d.people || [];
                d.toString = function(b) {
                    var a = \"mixpanel\";
                    \"mixpanel\" !== f && (a += \".\" + f);
                    b || (a += \" (stub)\");
                    return a
                };
                d.people.toString = function() {
                    return d.toString(1) + \".people (stub)\"
                };
                k = \"disable time_event track track_pageview track_links track_forms register register_once alias unregister identify name_tag set_config reset people.set people.set_once people.increment people.append people.union people.track_charge people.clear_charges people.delete_user\".split(\" \");
                for(h = 0; h < k.length; h++) e(d, k[h]);
                a._i.push([b, c, f])
            };
            a.__SV = 1.2;
            b = e.createElement(\"script\");
            b.type = \"text/javascript\";
            b.async = !0;
            b.src = \"undefined\" !== typeof MIXPANEL_CUSTOM_LIB_URL ? MIXPANEL_CUSTOM_LIB_URL : \"file:\" === e.location.protocol && \"//cdn.mxpnl.com/libs/mixpanel-2-latest.min.js\".match(/^\\/\\//) ? \"https://cdn.mxpnl.com/libs/mixpanel-2-latest.min.js\" : \"//cdn.mxpnl.com/libs/mixpanel-2-latest.min.js\";
            c = e.getElementsByTagName(\"script\")[0];
            c.parentNode.insertBefore(b, c)
        }
    })(document, window.mixpanel || []);
    mixpanel.init(\"\");
</script>
<script src=\"";
        // line 741
        echo asset("plugins/typeahead/js/handlebars.js");
        echo "\"></script>
<script src=\"";
        // line 742
        echo asset("plugins/typeahead/js/main.js");
        echo "\"></script>
<script src=\"";
        // line 743
        echo asset("js/app.js");
        echo "\"></script>
";
        // line 744
        $this->displayBlock('scripts', $context, $blocks);
        // line 745
        echo "</body>

</html>";
    }

    // line 261
    public function block_styles($context, array $blocks = [])
    {
        echo " ";
    }

    // line 540
    public function block_content($context, array $blocks = [])
    {
        echo " ";
    }

    // line 744
    public function block_scripts($context, array $blocks = [])
    {
        echo " ";
    }

    public function getTemplateName()
    {
        return "layouts/front.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1086 => 744,  1080 => 540,  1074 => 261,  1068 => 745,  1066 => 744,  1062 => 743,  1058 => 742,  1054 => 741,  983 => 673,  957 => 650,  913 => 609,  905 => 604,  901 => 603,  892 => 597,  888 => 596,  879 => 590,  875 => 589,  871 => 588,  867 => 587,  856 => 581,  844 => 572,  840 => 571,  835 => 569,  830 => 567,  826 => 566,  799 => 541,  797 => 540,  787 => 533,  780 => 529,  769 => 520,  762 => 516,  751 => 507,  749 => 506,  723 => 482,  717 => 479,  712 => 478,  704 => 474,  702 => 473,  686 => 460,  679 => 456,  674 => 453,  670 => 451,  668 => 450,  657 => 441,  649 => 436,  645 => 435,  641 => 434,  632 => 428,  627 => 426,  618 => 420,  614 => 419,  610 => 417,  602 => 412,  599 => 411,  597 => 410,  582 => 398,  544 => 363,  536 => 357,  534 => 356,  532 => 355,  530 => 354,  528 => 353,  526 => 352,  524 => 351,  522 => 350,  520 => 349,  518 => 348,  516 => 347,  514 => 346,  512 => 345,  510 => 344,  508 => 343,  500 => 338,  498 => 337,  494 => 335,  466 => 332,  456 => 303,  444 => 294,  435 => 290,  426 => 283,  424 => 282,  422 => 281,  420 => 280,  418 => 279,  416 => 278,  414 => 277,  412 => 276,  410 => 275,  408 => 274,  406 => 273,  404 => 272,  393 => 262,  391 => 261,  228 => 101,  186 => 62,  181 => 61,  177 => 59,  173 => 58,  169 => 57,  165 => 56,  161 => 55,  157 => 54,  153 => 53,  137 => 40,  133 => 39,  128 => 37,  124 => 36,  120 => 35,  116 => 34,  110 => 31,  106 => 30,  102 => 29,  97 => 27,  93 => 26,  89 => 25,  84 => 23,  80 => 22,  76 => 21,  72 => 20,  67 => 18,  61 => 15,  57 => 14,  53 => 13,  49 => 12,  45 => 11,  33 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "layouts/front.twig", "/home/bafredoc/new.bafredo.com/application/views/layouts/front.twig");
    }
}
