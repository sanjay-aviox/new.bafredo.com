<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* product/detail.twig */
class __TwigTemplate_e7df6214634dababec645f362cb62736c5f2ce37b2e514d217ed281f836fa0ae extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/front.twig", "product/detail.twig", 1);
        $this->blocks = [
            'styles' => [$this, 'block_styles'],
            'content' => [$this, 'block_content'],
            'scripts' => [$this, 'block_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "layouts/front.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_styles($context, array $blocks = [])
    {
        // line 3
        echo "\t<style type=\"text/css\">
\t\t.productNavFrame h3 {
\t\t\tdisplay: block;
\t\t}
        .input-group {
            position: relative;
            display: flex;
            border-collapse: separate;
            justify-content: left;
        }
        .plus-minus-input {
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
        }
        .productNavFrame .quantity .qtyNum label {
            padding-left: 10px;
        }
        .productNavFrame .quantity .qtyNum input {
            padding: 0px;
        }
        .item-quantity-count input {
            text-align: center;
        }
\t</style>
";
    }

    // line 29
    public function block_content($context, array $blocks = [])
    {
        // line 30
        echo "<div class=\"container-fluid bodyFrame\">
  <div class=\"row hidden-xs pc\">
  \t<div class=\"lineFrame\">
\t\t<ul class=\"breadcrumb\">
\t\t\t<li><a title=\"Home\" href=\"";
        // line 34
        echo twig_escape_filter($this->env, base_url("/"), "html", null, true);
        echo "\">Home</a></li>
\t\t\t<li><a title=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "getName", [], "method"), "html", null, true);
        echo "\" href='";
        echo twig_escape_filter($this->env, base_url(("product/detail/" . $this->getAttribute(($context["product"] ?? null), "getSlug", [], "method"))), "html", null, true);
        echo "'>";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "getName", [], "method"), "html", null, true);
        echo "</a></li>
\t\t</ul>
\t</div>
\t<div class=\"clear\"></div>
\t<div class=\"lineFrame\">
\t\t<div class=\"productNavFrame\">
\t  \t\t<h3>";
        // line 41
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "getName", [], "method"), "html", null, true);
        echo "</h3>
\t  \t\t<div class=\"price\">";
        // line 42
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "getPrice", [], "method"), "html", null, true);
        echo "</div>
\t        <div class=\"quantity\">
\t\t\t\t<div class=\"clear\"></div>
\t\t        <div class=\"qtyNum\">
\t\t  \t\t\t<label class=\"control-label\" for=\"input-quantity\">Qty</label>
\t\t\t\t\t<div class=\"input-group plus-minus-input\">
\t\t\t\t\t\t<div class=\"widgets-numberpicker\">
\t\t\t\t\t\t\t<div class=\"widgets-numberpicker-decrement\" v-on:click=\"decrementValue\"></div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"input-group-field item-quantity-count\">
\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control\" v-model=\"product_quantity\" v-on:keypress=\"onlyNumber\" maxlength=\"9\" minlength=\"1\">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"widgets-numberpicker\">
\t\t\t\t\t\t\t<div class=\"widgets-numberpicker-increment\" v-on:click=\"incrementValue\"></div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t  \t\t</div>
\t        </div>
\t  \t\t<div class=\"opations\"></div>
\t\t\t<button class=\"btn buyBtn\" v-on:click=\"addToCart(";
        // line 61
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "toJson", [], "method"), "html", null, true);
        echo ", 'redirectToCheckout')\">BUY IT NOW</button>
\t\t\t<button type=\"button\" v-on:click=\"addToCart(";
        // line 62
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "toJson", [], "method"), "html", null, true);
        echo ")\" class=\"addCartBtn\">ADD TO CART</button>
\t  \t\t<div class=\"clear\"></div>
\t  \t</div>

\t\t<div class=\"productLineFrame\">
\t\t\t<div class=\"thumbFrame\">
\t\t\t\t<div class=\"thumbShow\">
\t\t    \t\t<a rel=\"nofollow\" href=\"javascript:;\" title=\"";
        // line 69
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "getName", [], "method"), "html", null, true);
        echo "\">
\t\t    \t\t\t<img src='";
        // line 70
        echo asset(("uploads/product/thumbnail/" . $this->getAttribute(($context["product"] ?? null), "getImage", [], "method")));
        echo "' title=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "getName", [], "method"), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "getName", [], "method"), "html", null, true);
        echo "\" />
\t\t    \t\t</a>
\t\t    \t</div>
\t\t        <div class=\"thumbNav\">
\t\t        \t<span class=\"l\"><i class=\"iconfont icon-leftarrow2\"></i></span>
\t\t        \t<div class=\"thumbList\">
\t\t        \t\t<ul>
\t\t\t\t\t\t\t";
        // line 77
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["gallery"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["galleryObj"]) {
            // line 78
            echo "\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a rel=\"nofollow\" href=\"javascript:;\" title=\"";
            // line 79
            echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "getName", [], "method"), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t<img data-sourceimage='";
            // line 80
            echo asset(("uploads/product/gallery/" . $this->getAttribute($context["galleryObj"], "getImage", [], "method")));
            echo "' title=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "getName", [], "method"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "getName", [], "method"), "html", null, true);
            echo "\"
\t\t\t\t\t\t\t\t\t\t data-img='";
            // line 81
            echo asset(("uploads/product/gallery/" . $this->getAttribute($context["galleryObj"], "getImage", [], "method")));
            echo "' src='";
            echo asset(("uploads/product/gallery/" . $this->getAttribute($context["galleryObj"], "getImage", [], "method")));
            echo "'/>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t        </li>
\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['galleryObj'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 85
        echo "\t\t\t\t\t    </ul>
\t\t        \t</div>
\t\t        \t<span class=\"r\"><i class=\"iconfont icon-rightarrow2\"></i></span>
\t\t        </div>
\t    \t</div>
\t\t\t<div class=\"info\">
\t\t\t\t<h1>";
        // line 91
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "getName", [], "method"), "html", null, true);
        echo "</h1>
\t\t\t\t<div class=\"class\">
\t\t\t\t\t<span class=\"info_sku\">SKU: ";
        // line 93
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "getSku", [], "method"), "html", null, true);
        echo "</span><br/>
\t\t\t\t\t<span>Brand: ";
        // line 94
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "getBrand", [], "method"), "html", null, true);
        echo "</span><br/>
\t\t\t\t\t<span class=\"info_reward\">Reward Points: ";
        // line 95
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "getRewardPoints", [], "method"), "html", null, true);
        echo "</span><br/>
\t\t\t\t</div>
\t\t\t\t<br/>
\t\t\t\t";
        // line 99
        echo "\t\t\t\t\t";
        // line 100
        echo "\t\t\t\t\t";
        // line 101
        echo "\t\t\t\t\t\t";
        // line 102
        echo "\t\t\t\t\t\t";
        // line 103
        echo "\t\t\t\t\t\t";
        // line 104
        echo "\t\t\t\t\t\t";
        // line 105
        echo "\t\t\t\t\t\t";
        // line 106
        echo "\t\t\t\t\t";
        // line 107
        echo "\t\t\t\t";
        // line 108
        echo "\t\t\t\t<div class=\"tags\">
\t\t\t\t\t<p>Related Categories</p>
\t\t\t\t\t<p>
\t\t\t\t\t\t";
        // line 111
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["mainCategory"] ?? null), "getSubCategories", [], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["subCategory"]) {
            // line 112
            echo "\t\t\t\t\t\t\t<a title=\"Sensors\" href='";
            echo twig_escape_filter($this->env, base_url(((("category/" . $this->getAttribute(($context["mainCategory"] ?? null), "getSlug", [], "method")) . "/") . $this->getAttribute($context["subCategory"], "getSlug", [], "method"))), "html", null, true);
            echo "'>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["subCategory"], "getName", [], "method"), "html", null, true);
            echo "</a>
\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['subCategory'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 114
        echo "\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t\t<div class=\"clear\"></div>
\t\t\t\t<div class=\"addwish\">
\t\t\t\t\t<button type=\"button\" class=\"btn btn-default on\" v-on:click=\"addToWishList(";
        // line 118
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "id", []), "html", null, true);
        echo ")\">
\t\t\t\t\t\t<div class=\"oncon\">ADD TO WISHLIST</div>
\t\t\t\t\t\t<div class=\"offcon\">ON WISHLIST</div>
\t\t\t\t\t</button>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"clear\"></div>
\t</div>
\t<div class=\"lineFrame\">
\t\t<div class=\"productLineFrame productCon\">
\t\t\t<section class=\"info_INTRODUCTION\">
                <p><h4>INTRODUCTION</h4></p>
                <p>";
        // line 131
        echo $this->getAttribute(($context["product"] ?? null), "getIntroduction", [], "method");
        echo "<br /></p>
            </section>
\t\t</div>
\t</div>
\t<div class=\"lineFrame\">
\t\t<div class=\"productLineFrame disqusFrame\">
\t\t\t<h4>REVIEW</h4>
\t\t\t<!--disqus begin-->
\t\t\t<div id=\"disqus_thread\" style=\"width: 100%;\"></div>
\t\t\t<!--disqus end-->
\t\t</div>
\t</div>
\t<div class=\"lineFrame\">
\t\t<div class=\"productLineFrame\">
    \t\t<noscript>Please enable JavaScript to view the <a href=\"http://disqus.com/?ref_noscript\">comments powered by Disqus.</a></noscript>
\t\t</div>
\t</div>
  </div>
</div>
";
    }

    // line 151
    public function block_scripts($context, array $blocks = [])
    {
        // line 152
        echo "\t<script type=\"text/javascript\">
        // var disqus_shortname = 'bafredo';
        // var disqus_disable_mobile = true;
        // var disqus_identifier = 'prod-1333';
        // (function() {
        //     var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
        //     dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
        //     (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
        // })();
\t</script>
";
    }

    public function getTemplateName()
    {
        return "product/detail.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  302 => 152,  299 => 151,  275 => 131,  259 => 118,  253 => 114,  242 => 112,  238 => 111,  233 => 108,  231 => 107,  229 => 106,  227 => 105,  225 => 104,  223 => 103,  221 => 102,  219 => 101,  217 => 100,  215 => 99,  209 => 95,  205 => 94,  201 => 93,  196 => 91,  188 => 85,  176 => 81,  168 => 80,  164 => 79,  161 => 78,  157 => 77,  143 => 70,  139 => 69,  129 => 62,  125 => 61,  103 => 42,  99 => 41,  86 => 35,  82 => 34,  76 => 30,  73 => 29,  44 => 3,  41 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "product/detail.twig", "/home/bafredoc/new.bafredo.com/application/views/product/detail.twig");
    }
}
