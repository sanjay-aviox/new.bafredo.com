<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* login.twig */
class __TwigTemplate_b2e5cb264172777869102f6140deb6a107242124b9916f50f8a994de544fff49 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/front.twig", "login.twig", 1);
        $this->blocks = [
            'styles' => [$this, 'block_styles'],
            'content' => [$this, 'block_content'],
            'scripts' => [$this, 'block_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "layouts/front.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_styles($context, array $blocks = [])
    {
        // line 3
        echo "\t<style type=\"text/css\">
\t\t.facebook {
\t\t\twidth: 100% !important;
\t\t}
\t\t.askPassModal {
\t\t\twidth: 550px;
\t\t\theight: 200px;
\t\t\tmargin: 50px auto;
\t\t\tbackground: #eeeeee;
\t\t\tbox-shadow: 0px 0px 8px #ed6a00;
\t\t\tpadding: 30px 27px;
\t\t}
\t\t.askPassModal #btnModalContinue {
\t\t\tbackground: #ed6a00;
\t\t\tborder: none;
\t\t\twidth: 100%;
\t\t\theight: 40px;
\t\t\tcolor: #FFFFFF;
\t\t\tfont-weight: bold;
\t\t\tfont-size: 18px;
\t\t\tfont-weight: bold;
\t\t\ttext-transform: uppercase;
\t\t}
\t\t.login-frame {
\t\t\twidth: 650px;
\t\t\theight: 440px;
\t\t\tpadding: 34px 24px 39px 24px;
\t\t\tbackground: #FFFFFF;
\t\t\tmargin: 50px auto;
\t\t\t-webkit-box-shadow: 0px 0px 15px #d3d3d3;
\t\t\tbox-shadow: 0px 0px 15px #d3d3d3;
\t\t}
\t\t.login-frame .left-box {
\t\t\twidth: 301px;
\t\t\theight: 366px;
\t\t\tborder-right: 1px solid #D2D2D2;
\t\t\tpadding-right: 28px;
\t\t\tmargin-right: 28px;
\t\t\tposition: relative;
\t\t}
\t\t.login-frame .right-box {
\t\t\twidth: 273px;
\t\t\theight: 366px;
\t\t\tposition: relative;
\t\t}
\t\t.login-frame .btn-frame {
\t\t\theight: 68px;
\t\t\twidth: 273px;
\t\t\tposition: absolute;
\t\t\tbottom: 0;
\t\t}
\t\t.login-frame .btn-reg {
\t\t\theight: 45px;
\t\t\twidth: 100%;
\t\t\tdisplay: block;
\t\t\tbackground: #1d8229;
\t\t\tcolor: #FFFFFF;
\t\t\tfont-size: 16px;
\t\t\ttext-align: center;
\t\t\tline-height: 45px;
\t\t\tborder-radius: 3px;
\t\t}
\t\t.login-frame .facebook-btn {
\t\t\theight: 45px;
\t\t\twidth: 100%;
\t\t\tdisplay: block;
\t\t\tcursor: pointer;
\t\t\tbackground: #405993;
\t\t\tcolor: #FFFFFF;
\t\t\tfont-size: 16px;
\t\t\ttext-align: center;
\t\t\tline-height: 45px;
\t\t\tborder-radius: 3px;
\t\t}
\t\t.login-frame .or-line {
\t\t\theight: 21px;
\t\t\tmargin: 10px 0 12px 0;
\t\t\tposition: relative;
\t\t}
\t\t.login-frame .or-line b {
\t\t\tdisplay: block;
\t\t\tborder-bottom: 1px solid #D2D2D2;
\t\t\tposition: absolute;
\t\t\ttop: 10px;
\t\t\twidth: 100%;
\t\t}
\t\t.login-frame .or-line span {
\t\t\tdisplay: block;
\t\t\tbackground: #FFFFFF;
\t\t\twidth: 40px;
\t\t\tposition: absolute;
\t\t\tleft: 50%;
\t\t\tmargin-left: -20px;
\t\t\ttext-align: center;
\t\t\tfont-size: 16px;
\t\t\tcolor: #313131;
\t\t}
\t\t.login-frame .form-group input {
\t\t\tpadding-left: 18px;
\t\t\tmargin: 0;
\t\t\twidth: 226px;
\t\t\tborder: none;
\t\t\tline-height: 45px;
\t\t\tfont-size: 14px;
\t\t\theight: 45px;
\t\t\t-webkit-box-shadow: none;
\t\t\tbox-shadow: none;
\t\t}
\t\t.login-frame .login-btn {
\t\t\theight: 45px;
\t\t\twidth: 100%;
\t\t\tdisplay: block;
\t\t\tbackground: #1d8229;
\t\t\tcolor: #FFFFFF;
\t\t\tfont-size: 16px;
\t\t\ttext-align: center;
\t\t\tline-height: 45px;
\t\t\tborder-radius: 3px;
\t\t\tborder: none;
\t\t}
\t\t.login-frame .forgot-pwd-btn {
\t\t\theight: 45px;
\t\t\twidth: 100%;
\t\t\tdisplay: block;
\t\t\ttext-align: right;
\t\t\tmargin-top: 8px;
\t\t\tcolor: #23a1d1;
\t\t}
\t\t.login-frame .mail-input {
\t\t\twidth: 100%;
\t\t\theight: 45px;
\t\t\tborder: 1px solid #D2D2D2;
\t\t\tmargin-bottom: 20px;
\t\t\toverflow: hidden;
\t\t}
\t\t.login-frame .mail-input input {
\t\t\tpadding-left: 18px;
\t\t\tmargin: 0;
\t\t\twidth: 226px;
\t\t\tborder: none;
\t\t\tline-height: 45px;
\t\t\tfont-size: 14px;
\t\t\theight: 45px;
\t\t\t-webkit-box-shadow: none;
\t\t\tbox-shadow: none;
\t\t}
\t\t.login-frame .pwd-input {
\t\t\twidth: 100%;
\t\t\theight: 45px;
\t\t\tborder: 1px solid #D2D2D2;
\t\t\toverflow: hidden;
\t\t}
\t\t.login-frame .pwd-input input {
\t\t\tpadding-left: 28px;
\t\t\tmargin: 0;
\t\t\twidth: 226px;
\t\t\tborder: none;
\t\t\tline-height: 45px;
\t\t\tfont-size: 14px;
\t\t\theight: 45px;
\t\t\t-webkit-box-shadow: none;
\t\t\tbox-shadow: none;
\t\t}
        .alert-red {
            color: #B40005;
        }
\t</style>
";
    }

    // line 171
    public function block_content($context, array $blocks = [])
    {
        // line 172
        echo "\t<div class=\"container-fluid\">
\t\t<div class=\"login-frame\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-xs-12 col-md-6 left-box\">
\t\t\t\t\t<h3>New Customer</h3>
\t\t\t\t\t<div class=\"desc\">Creating an account helps you shop faster, check your order status, and track your shipment.</div>
\t\t\t\t\t<div class=\"btn-frame\">
\t\t\t\t\t\t<a class=\"btn-reg\" href=\"";
        // line 179
        echo twig_escape_filter($this->env, base_url("registration"), "html", null, true);
        echo "\">Create Your Account</a>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-xs-12 col-md-6 right-box\">
\t\t\t\t\t<h3>Returning Customer</h3>
\t\t\t\t\t<form action=\"";
        // line 184
        echo twig_escape_filter($this->env, base_url("login/process"), "html", null, true);
        echo "\" method=\"post\">
\t\t\t\t\t
                        <!--<input type=\"hidden\" name=\"redirectAfterLogin\" value=\"";
        // line 186
        echo twig_escape_filter($this->env, ($context["redirectAfterLogin"] ?? null), "html", null, true);
        echo "\">
\t\t\t\t\t\t<a class=\"facebook-btn\" onclick=\"loginfacebook()\"><i class=\"iconfont icon-facebook\"></i>login by Facebook</a>-->
\t\t\t\t\t\t<div class=\"or-line\">
\t\t\t\t\t\t\t<b></b>
\t\t\t\t\t\t\t<!--<span>or</span>-->
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"mail-input\">
\t\t\t\t\t\t\t<input spellcheck=\"false\" type=\"text\" name=\"email\" value=\"\" placeholder=\"Email or username \" id=\"input-email\" class=\"form-control\">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"pwd-input\">
\t\t\t\t\t\t\t<input spellcheck=\"false\" type=\"password\" name=\"password\" value=\"\" placeholder=\"Password\" id=\"input-password\" class=\"form-control\">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"row\" >
                        ";
        // line 199
        if (($context["error"] ?? null)) {
            // line 200
            echo "\t\t\t\t\t\t    <div class=\"alert alert-red\" >";
            echo twig_escape_filter($this->env, ($context["error"] ?? null), "html", null, true);
            echo "</div>
                        ";
        }
        // line 202
        echo "                        </div>
\t\t\t\t\t\t<div class=\"btn-frame\">
\t\t\t\t\t\t\t<input class=\"login-btn\" type=\"submit\" value=\"LOGIN\">
                            <a type=\"button\" class=\"forgot-pwd-btn chkBike\" data-toggle=\"modal\" data-target=\"#myModal\">Forgot Password?</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t</form>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>

\t<div class=\"modal fade askPassModal\" id=\"askPassModal\" data-backdrop=\"static\" data-keyboard=\"false\" role=\"dialog\">
\t\t<div class=\"form-group\">
\t\t\t<label class=\"control-label\" for=\"input-password\">Enter password to complete login process</label>
\t\t\t<input type=\"password\" name=\"password\" value=\"\" required placeholder=\"Password\" id=\"input-password\" class=\"form-control\"/>
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t<input type=\"button\" value=\"Continue\" id=\"btnModalContinue\"/>
\t\t</div>
\t</div>

    <!-- Modal -->
    <div class=\"modal fade\" id=\"myModal\" role=\"dialog\">
        <div class=\"modal-dialog\">

            <!-- Modal content-->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                    <h4 class=\"modal-title\">Forgot Password</h4>
                </div>
                <div class=\"modal-body mx-3\">
                    <form action=\"";
        // line 235
        echo twig_escape_filter($this->env, base_url("login/forgotpassword"), "html", null, true);
        echo "\" method=\"post\">
                        <div class=\"md-form mb-5\">
                            <label data-error=\"wrong\" data-success=\"right\" for=\"orangeForm-name\">Email</label>
                            <input type=\"text\" id=\"email\" required name=\"email\" class=\"form-control validate\">

                        </div>
                       <!-- <div class=\"md-form mb-5\">
                            <label data-error=\"wrong\" data-success=\"right\" for=\"orangeForm-name\">Password</label>
                            <input type=\"text\" id=\"password\" required name=\"password\" class=\"form-control validate\">

                        </div>
                        <div class=\"md-form mb-5\">
                            <label data-error=\"wrong\" data-success=\"right\" for=\"orangeForm-name\">Confirm Password</label>
                            <input type=\"text\" id=\"confirmpassword\" required name=\"confirmpassword\" class=\"form-control validate\">

                        </div>-->
                        <div class=\"modal-footer\">
                            <input type=\"submit\" class=\"btn btn-default\" >
                            <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                        </div>
                </div>
                </form>
            </div>

        </div>
    </div>
";
    }

    // line 262
    public function block_scripts($context, array $blocks = [])
    {
        // line 263
        echo "\t<script>
        (function(d, s, id){
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) {return;}
            js = d.createElement(s); js.id = id;
            js.src = \"https://connect.facebook.net/en_US/sdk.js\";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));

        window.fbAsyncInit = function() {
            FB.init({
                appId      : '485292091867337',
                cookie     : true,
                xfbml      : true,
                version    : 'v2.12'
            });

            FB.AppEvents.logPageView();
        };

        function checkLoginState()
        {
            FB.getLoginStatus(function(response) {
                if (response.status === 'connected') {
                    // Logged into your app and Facebook.
                    testAPI();
                } else {
                    // The person is not logged into your app or we are unable to tell.
                    document.getElementById('status').innerHTML = 'Please log ' + 'into this app.';
                    // statusChangeCallback(response);
                }
            });
        }

        function loginfacebook()
        {
            FB.login(function(response) {
                // handle the response
                if (response.status === 'connected') {
                    // Logged into your app and Facebook.
                    testAPI();
                } else {
                    // The person is not logged into your app or we are unable to tell.
                    document.getElementById('status').innerHTML = 'Please log ' + 'into this app.';
                }
            }, {scope: 'public_profile,email'});
        }

        function testAPI()
        {
            console.log('Welcome!  Fetching your information.... ');
            FB.api('/me?fields=name,email,first_name,last_name,id,gender,picture', function(response) {
                if(response.name != null){
                    console.log(response);
                    // Ask user for password
                    // \$(\"#askPassModal\").modal(\"show\");
                    // \$(\"#btnModalContinue\").click(function () {
                    // var password = \$(\"#askPassModal input[name=password]\");
                    // if (password.val() != \"\") {
                    // \$('#askPassModal').modal('hide');
                    process_login(response);
                    // } else {
                    // password.css(\"border\", \"solid 1px red\");
                    // }
                    // });
                    // \$(window).on('hidden.bs.modal', function() {});
                } else {
                    alert(\"It fails to login within third part.\");
                }
            }, {scope: 'public_profile,email'});
        }

        function process_login(response)
        {
            if (response.email == undefined) {
                alert(\"You facebook email is rquired, Kindly grant us permission.\");
                window.location.reload();
            }

            \$.ajax({
                url:\"";
        // line 343
        echo twig_escape_filter($this->env, base_url("login/facebook"), "html", null, true);
        echo "\",
                data:{
                    fb_id:response.id,
                    userName:response.name,
                    firstName:response.first_name,
                    lastName:response.last_name,
                    email:response.email,
                    gender:response.gender,
                    picture:response.picture
                },
                dataType:\"json\",
                type:\"post\",
                success:function(data){
                    console.log(data);
                    window.location.href = data.href;
                }
            });
        }
\t</script>
";
    }

    public function getTemplateName()
    {
        return "login.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  415 => 343,  333 => 263,  330 => 262,  299 => 235,  264 => 202,  258 => 200,  256 => 199,  240 => 186,  235 => 184,  227 => 179,  218 => 172,  215 => 171,  44 => 3,  41 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "login.twig", "/home/bafredoc/new.bafredo.com/application/views/login.twig");
    }
}
