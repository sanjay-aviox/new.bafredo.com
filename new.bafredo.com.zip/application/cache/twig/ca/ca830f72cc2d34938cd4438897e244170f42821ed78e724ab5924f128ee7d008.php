<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/user/account.twig */
class __TwigTemplate_0a4f08f48ae45aed172d35db9dcc9c802acf1b6db8d1788630e7065256359e87 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<h2>Personal Information</h2>
<div class=\"orderListFrame\">
    <form action=\"#\" method=\"post\" enctype=\"multipart/form-data\" class=\"form-horizontal\">
        <fieldset>
            <legend></legend>
            <div class=\"form-group\">
                <label class=\"col-sm-2 control-label\" for=\"name\">Name</label>
                <div class=\"col-sm-10\">
                    <input type=\"text\" name=\"name\" required value=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "name", []), "html", null, true);
        echo "\" placeholder=\"Name\" id=\"name\" class=\"form-control\">
                </div>
            </div>
            ";
        // line 12
        if ($this->getAttribute(($context["verfiy"] ?? null), "code", [])) {
            // line 13
            echo "            <div class=\"text-center bg-danger\"><span class=\"alert\">
                   Unverified Email</span></div>
            ";
        }
        // line 16
        echo "            <div class=\"form-group\">
                <label class=\"col-sm-2 control-label\" for=\"email\">Email</label>
                <div class=\"col-sm-10\">
                    <input type=\"text\" name=\"email\" required value=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "email", []), "html", null, true);
        echo "\" placeholder=\"Email\" id=\"email\" class=\"form-control\">
                </div>
            </div>
            <div class=\"form-group\">
                <label class=\"col-sm-2 control-label\" for=\"telephone\">Mobile Number</label>
                <div class=\"col-sm-10\">
                    <input type=\"text\" name=\"telephone\" required value=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "telephone", []), "html", null, true);
        echo "\" placeholder=\"Mobile Number\" id=\"telephone\" class=\"form-control\">
                </div>
            </div>
        </fieldset>
        <div class=\"buttons clearfix\">
            <div class=\"pull-right\">
                <input type=\"submit\" value=\"Save\" class=\"btn btn-primary\">
            </div>
        </div>
    </form>
</div>";
    }

    public function getTemplateName()
    {
        return "partials/user/account.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 25,  58 => 19,  53 => 16,  48 => 13,  46 => 12,  40 => 9,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "partials/user/account.twig", "/home/bafredoc/new.bafredo.com/application/views/partials/user/account.twig");
    }
}
