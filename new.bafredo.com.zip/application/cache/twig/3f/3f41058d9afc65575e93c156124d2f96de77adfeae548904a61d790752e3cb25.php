<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* user/profile.twig */
class __TwigTemplate_8b3522a9ae23d8b7b96feb57a680190f91699075b2fa9f2fa6728a23d710848a extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/front.twig", "user/profile.twig", 1);
        $this->blocks = [
            'styles' => [$this, 'block_styles'],
            'content' => [$this, 'block_content'],
            'scripts' => [$this, 'block_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "layouts/front.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_styles($context, array $blocks = [])
    {
        // line 3
        echo "    <style type=\"text/css\">
        .bodyFrame .pc .accountFrame .leftFrame .accountNav .select {
            background: #0f054a;
            color: #FFFFFF;
        }
        .bodyFrame .pc .accountFrame .rightFrame .btn {
            width: auto;
            height: auto;
            font-size: 12px;
        }
        .btn-danger {
            color: #fff !important;
            background-color: #d9534f !important;
            border-color: #d43f3a !important;
        }
        .progress {
            display: none;
            position: absolute;
            width: 295px;
            background-color: green;
            border: 0px solid blue;
            padding: 0px;
            border-radius: 3px;
        }

        .progress-bar {
            background-color: green;
            width: 0%;
            height: 30px;
            border-radius: 4px;
            -webkit-border-radius: 4px;
            -moz-border-radius: 4px;
        }

        .percent {
            position: absolute;
            display: inline-block;
            color: #fff;
            font-weight: bold;
            top: 50%;
            text-align: center !important;
            margin-top: -9px;
            margin-left: -20px;
            -webkit-border-radius: 4px;
        }
    </style>
";
    }

    // line 50
    public function block_content($context, array $blocks = [])
    {
        // line 51
        echo "
    <div class=\"row pc\">
        ";
        // line 53
        if ( !twig_test_empty(($context["success"] ?? null))) {
            // line 54
            echo "            <div class=\"alert alert-success\">
                <strong>Success! </strong> Updated successfully.
            </div>
        ";
        }
        // line 58
        echo "        <div class=\"lineFrame\">
            <ul class=\"breadcrumb\">
                <li><a href=\"";
        // line 60
        echo twig_escape_filter($this->env, base_url("/"), "html", null, true);
        echo "\"><i class=\"fa fa-home\"></i></a></li>
                <li><a href=\"";
        // line 61
        echo twig_escape_filter($this->env, base_url("account"), "html", null, true);
        echo "\">Account</a></li>
            </ul>
        </div>
        <div class=\"clear\"></div>
        <div class=\"lineFrame accountTit\">
            My Account
        </div>
        <div class=\"lineFrame accountFrame\">
            <div class=\"leftFrame\">
                <aside id=\"column-right\">
                    <div class=\"myName\">
                        <div class=\"head\">
                            <img src=\"";
        // line 73
        echo twig_escape_filter($this->env, ((twig_test_empty($this->getAttribute(($context["user"] ?? null), "getUserImg", [], "method"))) ? (base_url("assets/front/image/profile.png")) : ((base_url("assets/front/image/users/") . $this->getAttribute(($context["user"] ?? null), "getUserImg", [], "method")))), "html", null, true);
        echo "  \" class=\"profile-content profile\"  alt=\"my head\">
                            <lable>Max size is 2 Mb</lable>
                            <input id=\"hprofile\" type=\"file\"  alt=\"my head\">
                        </div>
                        <div class=\"text\">
                            <h4>";
        // line 78
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "getName", [], "method"), "html", null, true);
        echo "</h4>
                            <h6>";
        // line 79
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "getEmail", [], "method"), "html", null, true);
        echo "</h6>
                            <h6>";
        // line 80
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "getTelephone", [], "method"), "html", null, true);
        echo "</h6>

                        </div>
                    </div>
                    <div class=\"accountNav\" style=\"margin-top: 44px;\">
                        <a class=\"aMenu_0 ";
        // line 85
        echo (((($context["page"] ?? null) == "account")) ? ("select") : (""));
        echo "\" href=\"";
        echo twig_escape_filter($this->env, base_url("account"), "html", null, true);
        echo "\">My Account</a>
                        <hr>
                        <a class=\"aMenu_1 ";
        // line 87
        echo (((($context["page"] ?? null) == "order_history")) ? ("select") : (""));
        echo "\" href=\"";
        echo twig_escape_filter($this->env, base_url("account/order_history"), "html", null, true);
        echo "\">Order History</a>
                        <hr>
                        <a class=\"aMenu_2 ";
        // line 89
        echo (((($context["page"] ?? null) == "address_book")) ? ("select") : (""));
        echo "\" href=\"";
        echo twig_escape_filter($this->env, base_url("account/address_book"), "html", null, true);
        echo "\">Address Book</a>
                        <hr>
                        <a class=\"aMenu_3 ";
        // line 91
        echo (((($context["page"] ?? null) == "wish_list")) ? ("select") : (""));
        echo "\" href=\"";
        echo twig_escape_filter($this->env, base_url("account/wish_list"), "html", null, true);
        echo "\">Wishlist</a>
                        <hr>
                        ";
        // line 94
        echo "                        ";
        // line 95
        echo "                        <!--<a class=\"aMenu_7\" href=\"https://www.dfrobot.com/index.php?route=account/transaction&tab=transaction\">Store Credit</a>-->
                        <hr>

                        ";
        // line 99
        echo "                        ";
        // line 100
        echo "                        <a href=\"";
        echo twig_escape_filter($this->env, base_url("user/logout"), "html", null, true);
        echo "\">Logout</a>
                    </div>
                </aside>
            </div>

            <div class=\"rightFrame\">
                ";
        // line 106
        echo twig_include($this->env, $context, (("partials/user/" . ($context["page"] ?? null)) . ".twig"));
        echo "
            </div>

        </div>
    </div>
";
    }

    // line 113
    public function block_scripts($context, array $blocks = [])
    {
        // line 114
        echo "
    <script>
        function readProfile(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    \$('.profile').attr('src', '";
        // line 121
        echo twig_escape_filter($this->env, base_url("assets/front/image/loading.gif"), "html", null, true);
        echo "');
                }
                reader.readAsDataURL(input.files[0]);
                var fd = new FormData();
                var files = input.files[0];
                fd.append('file', files);
                var old_image = \"";
        // line 127
        echo twig_escape_filter($this->env, ((twig_test_empty($this->getAttribute(($context["user"] ?? null), "getUserImg", [], "method"))) ? (base_url("assets/front/image/profile.png")) : ((base_url("assets/front/image/users/") . $this->getAttribute(($context["user"] ?? null), "getUserImg", [], "method")))), "html", null, true);
        echo "\"
                \$.ajax({
                    url: '";
        // line 129
        echo twig_escape_filter($this->env, base_url("account/upload_profile"), "html", null, true);
        echo "',
                    type: 'post',
                    data: fd,
                    contentType: false,
                    processData: false,
                    beforeSend : function() {

                    },
                    xhr: function() {
                        var xhr = new window.XMLHttpRequest();
                        xhr.upload.addEventListener(\"progress\", function(evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = (evt.loaded / evt.total) * 100;
                                \$(\"#progressBar\").animate({
                                    width: '' + percentComplete + ''
                                }, {
                                    duration: 5000,
                                    easing: \"linear\",
                                    step: function (x) {
                                            percentText = Math.round(x * 100 / percentComplete);
                                    }
                                });
                            }
                        }, false);
                        return xhr;
                    },
                    success: function(response){
                        var par_obj = JSON.parse(response);
                        if(par_obj.status == \"success\"){
                            \$('.profile').attr('src', '";
        // line 158
        echo twig_escape_filter($this->env, base_url("assets/front/image/users/"), "html", null, true);
        echo "'+par_obj.name);
                            alert(\"Updated succesffully\")
                        }
                        else{
                            alert(par_obj.name.replace(/<[^>]*>/g, ''));
                            \$('.profile').attr('src', old_image);

                        }
                    },
                });
            }
        }

        \$(\"#hprofile\").change(function () {
            readProfile(this);


        });

    </script>
";
    }

    public function getTemplateName()
    {
        return "user/profile.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  271 => 158,  239 => 129,  234 => 127,  225 => 121,  216 => 114,  213 => 113,  203 => 106,  193 => 100,  191 => 99,  186 => 95,  184 => 94,  177 => 91,  170 => 89,  163 => 87,  156 => 85,  148 => 80,  144 => 79,  140 => 78,  132 => 73,  117 => 61,  113 => 60,  109 => 58,  103 => 54,  101 => 53,  97 => 51,  94 => 50,  44 => 3,  41 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "user/profile.twig", "/home/bafredoc/new.bafredo.com/application/views/user/profile.twig");
    }
}
