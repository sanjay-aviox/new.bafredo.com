<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home.twig */
class __TwigTemplate_bb30adacd61b39a5dcc75c4b94411f2cdaff307f39790d62261625a50ecc424b extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/front.twig", "home.twig", 1);
        $this->blocks = [
            'styles' => [$this, 'block_styles'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "layouts/front.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_styles($context, array $blocks = [])
    {
        // line 3
        echo "    <style type=\"text/css\">
        .mobile .smallBanner .row .right-padding-no {
            padding-right: 0px;
        }
        .mobile .smallBanner .row .left-padding-no {
            padding-left: 0px;
        }
        .pl .productTitle {
            margin-top: 27px;
        }
        .img-responsive {
             height: auto !important;
        }
    </style>
";
    }

    // line 18
    public function block_content($context, array $blocks = [])
    {
        // line 19
        echo "
    <div class=\"container-fluid bodyFrame\">
        <div class=\"row hidden-xs pc\">
            <div class=\"lineFrame\">
                <aside id=\"column-left\" class=\"hidden-xs\">
                    <div class=\"categoryFrame\">
                        <div class=\"title\">CATEGORY</div>
                        ";
        // line 26
        echo twig_include($this->env, $context, "partials/home/menus.twig");
        echo "
                    </div>
                </aside>

                <aside id=\"column-right\">
                    <div class=\"bigeyeSource\" data-size=\"950_475\" style=\"display: none;\">
                        <ul>
                            <li data-video=\"\" data-url=\"#\" data-img=\"";
        // line 33
        echo asset("front/image/banner/5.jpg");
        echo "\" data-title=\"produt-title\">
                            </li>
                            <li data-video=\"\" data-url=\"#\" data-img=\"";
        // line 35
        echo asset("front/image/banner/4.jpg");
        echo "\" data-title=\"produt-title\">
                            </li>
                            <li data-video=\"\" data-url=\"#\" data-img=\"";
        // line 37
        echo asset("front/image/banner/3.jpg");
        echo "\" data-title=\"produt-title\">
                            </li>
                        </ul>
                    </div>
                    <div class=\"bigeye\" data-size=\"950_475\"></div>
                </aside>

                <div class=\"smallBanner\">
                    <a target=\"_blank\" href=\"";
        // line 45
        echo twig_escape_filter($this->env, base_url("detail"), "html", null, true);
        echo "\"><img src=\"";
        echo asset("front/image/banner/1.png");
        echo "\" alt=\"icon\" width=\"470px\" height=\"200px\"/></a>
                    <a target=\"_blank\" href=\"";
        // line 46
        echo twig_escape_filter($this->env, base_url("detail"), "html", null, true);
        echo "\"><img src=\"";
        echo asset("front/image/banner/7.jpg");
        echo "\" alt=\"icon\" width=\"470px\" height=\"200px\"/></a>
                </div>
            </div>

            <div class=\"clear\"></div>

            ";
        // line 53
        echo "                ";
        // line 54
        echo "            ";
        // line 55
        echo "
            ";
        // line 57
        echo "                ";
        // line 58
        echo "                    ";
        // line 59
        echo "                        ";
        // line 60
        echo "                    ";
        // line 61
        echo "                    ";
        // line 62
        echo "                        ";
        // line 63
        echo "                    ";
        // line 64
        echo "                    ";
        // line 65
        echo "                        ";
        // line 66
        echo "                    ";
        // line 67
        echo "                    ";
        // line 68
        echo "                        ";
        // line 69
        echo "                    ";
        // line 70
        echo "                ";
        // line 71
        echo "            ";
        // line 72
        echo "
            ";
        // line 73
        echo twig_include($this->env, $context, "partials/home/product_list.twig");
        echo "
        </div>

        <div class=\"visible-xs mobile\">
            <div class=\"lineFrame\">
                <div class=\"byFrame\"></div>
                <div class=\"smallBanner\">
                    <div class=\"row\">
                        <div class=\"col-xs-6 right-padding-no\">
                            <a target=\"_blank\" href=\"#\">
                                <img src=\"";
        // line 83
        echo asset("front/image/banner/1.png");
        echo "\" alt=\"icon\" width=\"100%\" height=\"100px\"/>
                            </a>
                        </div>
                        <div class=\"col-xs-6 left-padding-no\">
                            <a target=\"_blank\" href=\"#\">
                                <img src=\"";
        // line 88
        echo asset("front/image/banner/7.jpg");
        echo "\" alt=\"icon\" width=\"100%\" height=\"100px\"/>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class=\"clear\"></div>

            ";
        // line 98
        echo "                ";
        // line 99
        echo "                    ";
        // line 100
        echo "                        ";
        // line 101
        echo "                    ";
        // line 102
        echo "                    ";
        // line 103
        echo "                        ";
        // line 104
        echo "                    ";
        // line 105
        echo "                    ";
        // line 106
        echo "                        ";
        // line 107
        echo "                    ";
        // line 108
        echo "                    ";
        // line 109
        echo "                        ";
        // line 110
        echo "                    ";
        // line 111
        echo "                ";
        // line 112
        echo "            ";
        // line 113
        echo "
            ";
        // line 114
        echo twig_include($this->env, $context, "partials/home/product_list.twig");
        echo "
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "home.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  227 => 114,  224 => 113,  222 => 112,  220 => 111,  218 => 110,  216 => 109,  214 => 108,  212 => 107,  210 => 106,  208 => 105,  206 => 104,  204 => 103,  202 => 102,  200 => 101,  198 => 100,  196 => 99,  194 => 98,  182 => 88,  174 => 83,  161 => 73,  158 => 72,  156 => 71,  154 => 70,  152 => 69,  150 => 68,  148 => 67,  146 => 66,  144 => 65,  142 => 64,  140 => 63,  138 => 62,  136 => 61,  134 => 60,  132 => 59,  130 => 58,  128 => 57,  125 => 55,  123 => 54,  121 => 53,  110 => 46,  104 => 45,  93 => 37,  88 => 35,  83 => 33,  73 => 26,  64 => 19,  61 => 18,  43 => 3,  40 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "home.twig", "/home/bafredoc/new.bafredo.com/application/views/home.twig");
    }
}
