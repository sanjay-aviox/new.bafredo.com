<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/home/menus.twig */
class __TwigTemplate_f19071dfc07e1f0e0dd817d6edb56df1c94927f54651cd5829289f777adbc24a extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"list\">
    <ul>
        <li><a class=\"subNaveBtn\" title=\"New Products\" rel=\"nofollow\" href=\"";
        // line 3
        echo twig_escape_filter($this->env, base_url("product/new"), "html", null, true);
        echo "\">New Products</a></li>
        <li><a class=\"subNaveBtn\" title=\"Sales\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, base_url("product/sales"), "html", null, true);
        echo "\">Sales</a></li>
        <li><a class=\"subNaveBtn\" title=\"All Products\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, base_url("product/all"), "html", null, true);
        echo "\">All Products</a></li>
        ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["menus"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["menu"]) {
            // line 7
            echo "        <li>
            <a title=\"Arduino\" class=\"subNaveBtn\" href='";
            // line 8
            echo twig_escape_filter($this->env, base_url(("category/" . $this->getAttribute($context["menu"], "getSlug", [], "method"))), "html", null, true);
            echo "'>
                <span class=\"l\">";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute($context["menu"], "getName", [], "method"), "html", null, true);
            echo "</span>
                <span class=\"r\">></span>
            </a>
            <div class=\"childData\">
                <div class=\"sn\">
                    <ul class=\"\">
                        ";
            // line 15
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["menu"], "getSubCategories", [], "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["smenu"]) {
                // line 16
                echo "                        <li><a title=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["smenu"], "getName", [], "method"), "html", null, true);
                echo "\" href='";
                echo twig_escape_filter($this->env, base_url(((("category/" . $this->getAttribute($context["menu"], "getSlug", [], "method")) . "/") . $this->getAttribute($context["smenu"], "getSlug", [], "method"))), "html", null, true);
                echo "'>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["smenu"], "getName", [], "method"), "html", null, true);
                echo "</a></li>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['smenu'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 18
            echo "                    </ul>
                </div>
                <div class=\"rc\">
                    <div class=\"title\">You may also like</div>
                    <ul>
                        <li>
                            <a title=\"Beginner Kit for Arduino (Best Starter Kit)\" href=\"";
            // line 24
            echo twig_escape_filter($this->env, base_url("detail"), "html", null, true);
            echo "\">
                                <img src=\"";
            // line 25
            echo asset("front/image/category/menu/1.jpg");
            echo "\" alt=\"Beginner Kit for Arduino (Best Starter Kit)\">
                                <span class=\"name\">
                                Beginner Kit for Arduino (Best Starter Kit)\t                \t\t</span>
                                <span class=\"mask\"></span>
                                <b class=\"price\">
                                    \$52.90\t\t\t                        \t\t\t                    \t                \t\t</b>
                            </a>
                        </li>
                        <li>
                            <a title=\"DFRduino UNO R3 - Arduino Compatible\" href=\"";
            // line 34
            echo twig_escape_filter($this->env, base_url("detail"), "html", null, true);
            echo "\">
                                <img src=\"";
            // line 35
            echo asset("front/image/category/menu/1.jpg");
            echo "\" alt=\"DFRduino UNO R3 - Arduino Compatible\">
                                <span class=\"name\">
                                DFRduino UNO R3 - Arduino Compatible\t                \t\t</span>
                                <span class=\"mask\"></span>
                                <b class=\"price\">
                                    \$19.90\t\t\t                        \t\t\t                    \t                \t\t</b>
                            </a>
                        </li>
                        <li>
                            <a title=\"Gravity: 1602 LCD Keypad Shield For Arduino\" href=\"";
            // line 44
            echo twig_escape_filter($this->env, base_url("detail"), "html", null, true);
            echo "\">
                                <img src=\"";
            // line 45
            echo asset("front/image/category/menu/1.jpg");
            echo "\" alt=\"Gravity: 1602 LCD Keypad Shield For Arduino\">
                                <span class=\"name\">
                                Gravity: 1602 LCD Keypad Shield For Arduino\t                \t\t</span>
                                <span class=\"mask\"></span>
                                <b class=\"price\">
                                    \$9.90\t\t\t                        \t\t\t                    \t                \t\t</b>
                            </a>
                        </li>
                        <li>
                            <a title=\"RGB LED Strip Driver Shield v1.0\" href=\"";
            // line 54
            echo twig_escape_filter($this->env, base_url("detail"), "html", null, true);
            echo "\">
                                <img src=\"";
            // line 55
            echo asset("front/image/category/menu/1.jpg");
            echo "\" alt=\"RGB LED Strip Driver Shield v1.0\">
                                <span class=\"name\">
                                RGB LED Strip Driver Shield v1.0\t                \t\t</span>
                                <span class=\"mask\"></span>
                                <b class=\"price\">
                                    \$12.05\t\t\t                        \t\t\t                    \t                \t\t</b>
                            </a>
                        </li>
                        <li>
                            <a title=\"FireBeetle ESP32 IOT Microcontroller (Supports Wi-Fi &amp; Bluetooth)\" href=\"";
            // line 64
            echo twig_escape_filter($this->env, base_url("detail"), "html", null, true);
            echo "\">
                                <img src=\"";
            // line 65
            echo asset("front/image/category/menu/1.jpg");
            echo "\" alt=\"FireBeetle ESP32 IOT Microcontroller (Supports Wi-Fi &amp; Bluetooth)\">
                                <span class=\"name\">
                                FireBeetle ESP32 IOT Microcontroller (Supports Wi-Fi &amp; Bluetooth)\t                \t\t</span>
                                <span class=\"mask\"></span>
                                <b class=\"price\">
                                    \$19.00\t\t\t                        \t\t\t                    \t                \t\t</b>
                            </a>
                        </li>
                        <li>
                            <a title=\"W5500 Ethernet with POE IOT Board (Arduino Compatible)\" href=\"";
            // line 74
            echo twig_escape_filter($this->env, base_url("detail"), "html", null, true);
            echo "\">
                                <img src=\"";
            // line 75
            echo asset("front/image/category/menu/1.jpg");
            echo "\" alt=\"W5500 Ethernet with POE IOT Board (Arduino Compatible)\">
                                <span class=\"name\">
                                W5500 Ethernet with POE IOT Board (Arduino Compatible)\t                \t\t</span>
                                <span class=\"mask\"></span>
                                <b class=\"price\">
                                    \$44.90\t\t\t                        \t\t\t                    \t                \t\t</b>
                            </a>
                        </li>
                        <li>
                            <a title=\"Gravity IO Expansion Shield for Arduino V7.1\" href=\"";
            // line 84
            echo twig_escape_filter($this->env, base_url("detail"), "html", null, true);
            echo "\">
                                <img src=\"";
            // line 85
            echo asset("front/image/category/menu/1.jpg");
            echo "\" alt=\"Gravity IO Expansion Shield for Arduino V7.1\">
                                <span class=\"name\">
                                Gravity IO Expansion Shield for Arduino V7.1\t                \t\t</span>
                                <span class=\"mask\"></span>
                                <b class=\"price\">
                                    \$8.90\t\t\t                        \t\t\t                    \t                \t\t</b>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menu'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 98
        echo "    </ul>
</div>";
    }

    public function getTemplateName()
    {
        return "partials/home/menus.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  210 => 98,  191 => 85,  187 => 84,  175 => 75,  171 => 74,  159 => 65,  155 => 64,  143 => 55,  139 => 54,  127 => 45,  123 => 44,  111 => 35,  107 => 34,  95 => 25,  91 => 24,  83 => 18,  70 => 16,  66 => 15,  57 => 9,  53 => 8,  50 => 7,  46 => 6,  42 => 5,  38 => 4,  34 => 3,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "partials/home/menus.twig", "/home/bafredoc/new.bafredo.com/application/views/partials/home/menus.twig");
    }
}
