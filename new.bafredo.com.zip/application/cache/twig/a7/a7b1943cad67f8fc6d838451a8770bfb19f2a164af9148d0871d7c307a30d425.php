<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* cart/checkout.twig */
class __TwigTemplate_78a4d34c51ee59129187bed96f329da4e4d24e6589912ef8eef7ae17f2727a93 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/front.twig", "cart/checkout.twig", 1);
        $this->blocks = [
            'styles' => [$this, 'block_styles'],
            'content' => [$this, 'block_content'],
            'scripts' => [$this, 'block_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "layouts/front.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_styles($context, array $blocks = [])
    {
        // line 3
        echo "\t<style>
\t\t.lineFrame h2 {
\t\t\tcolor: #0f054a;
\t\t\tfont-size: 30px;
\t\t\tfont-weight: bold;
\t\t}
\t\t.bodyFrame .pc .shoppingNavFrame {
            width: 100%;
            height: 89px;
            position: relative;
        }
        .bodyFrame .pc .shoppingNavFrame b {
            display: block;
            position: absolute;
            font-size: 30px;
            color: #0f054a;
            top: 35px;
        }
        .bodyFrame .pc .shoppingNavFrame ul {
            position: absolute;
            top: 27px;
            right: 0;
        }
        .bodyFrame .pc .shoppingNavFrame ul .select {
            border-bottom: 4px solid #ED6A00;
            color: #ED6A00;
        }
        .bodyFrame .pc .shoppingNavFrame ul .select {

            color: #ED6A00;

        }
        .bodyFrame .pc .shoppingNavFrame ul li {
            color: #707070;
            font-size: 18px;
            font-weight: bold;
            width: 166px;
            float: left;
            margin-left: 20px;
            border-bottom: 4px solid #A2A2A2;
            line-height: 30px;
            text-align: center;
        }
        .bodyFrame .pc .shoppingNavFrame ul li {
            color: #707070;
            font-size: 18px;
            font-weight: bold;
            line-height: 30px;
            text-align: center;
        }
        .bodyFrame .pc .lineFrame {
            width: 1200px;
            min-height: 40px;
            position: relative;
        }
        .cart-table {
        \tborder-bottom: 2px solid #ddd;
        }
        .cart-table th, td {
            color: #535353;
            font-size: 18px;
        }
        .cart-table td:last-child,
        .cart-table th:last-child {
        \ttext-align: right;
        }
        .cart-footer {
        \tfloat: right;
        }
        .cart-footer td {
        \tpadding-left: 100px;
        \tpadding-bottom: 10px;
        \tcolor: #535353;
            font-size: 18px;
        }
        .cart-footer .btn-contine {
        \ttext-align: right;
        \tmargin-top: 20px;
        }
        .cart-footer .btn-contine button {
        \twidth: 250px;
        }
        .cart-table img {
            width: 94px;
            height: 63px;
            padding: 0;
            margin: 0;
            border: none;
            border-radius: 0;
        }
        .cart-table .img-thumbnail {
            display: inline-block;
            max-width: 100%;
            height: auto;
            padding: 4px;
            line-height: 1.42857143;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 4px;
            -webkit-transition: all .2s ease-in-out;
            -o-transition: all .2s ease-in-out;
            transition: all .2s ease-in-out;
            float: left;
        \tmargin-right: 10px;
        }
        .btn-confirm {
        \tdisplay: block;
            width: 250px;
            height: 49px;
            line-height: 49px;
            background: #1d8229;
            border: solid 1px #1d8229;
            color: #FFFFFF;
            float: right;
            font-size: 20px;
            text-align: center;
            font-weight: bold;
            cursor: pointer;
        }
        .footer-row {
        \tfont-size: 20px;
            margin: 27px 0px;
            background: #0f054a;
            color: #fff;
            padding: 30px;
            display: block;
            text-align: center;
        }
\t\t.save-address {
\t\t\tfont-size: 17px;
\t\t\tmargin-left: 6px;
\t\t\tfont-style: italic;
\t\t\tcolor: #8a8a8a;
\t\t}
        .red-asterisk {
            color: red;
        }
        .sec-shipping-method label,
        .sec-payment-method label,
        .sec-agreement label {
            font-size: 14px;
        }
        .info-message {
            margin: 10px;
            font-style: italic;
        }
\t\t.bank-detail {
\t\t\ttransition: opacity 0.5s;
\t\t}
\t\t.bank-detail[style*=\"display: none;\"] {
\t\t\topacity: 0;
\t\t\tpointer-events: none; /* disable user interaction */
\t\t\tuser-select: none; /* disable user selection */
\t\t}
\t</style>
";
    }

    // line 159
    public function block_content($context, array $blocks = [])
    {
        // line 160
        echo "\t<div class=\"container-fluid bodyFrame\">
        <div class=\"row pc checkoutApp\">
        \t<div class=\"lineFrame\">
                <ul class=\"breadcrumb\">
                    <li><a href=\"";
        // line 164
        echo twig_escape_filter($this->env, base_url("/"), "html", null, true);
        echo "\"><i class=\"fa fa-home\"></i></a></li>
                    <li><a href=\"";
        // line 165
        echo twig_escape_filter($this->env, base_url("cart/checkout"), "html", null, true);
        echo "\">Checkout</a></li>
                </ul>
            </div>
            <div class=\"clear\"></div>
            <div class=\"lineFrame\">
\t\t\t\t<form action=\"";
        // line 170
        echo twig_escape_filter($this->env, base_url("cart/confirm"), "html", null, true);
        echo "\" class=\"form\" method=\"post\">
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<h2>Cart Checkout</h2>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<div class=\"shoppingNavFrame\">
\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t<li>1. Shopping Cart</li>
\t\t\t\t\t\t\t\t\t<li class=\"select\">2. Check Out</li>
\t\t\t\t\t\t\t\t\t<li>3. Confirm Order</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<h3>Shipping Address</h3>
\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<label for=\"first_name\">First Name <span class=\"red-asterisk\">*</span></label>
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"shippingAddress[first_name]\" value=\"";
        // line 192
        echo formdata("first_name", $this->getAttribute(($context["shippingAddress"] ?? null), "first_name", []));
        echo "\" required id=\"first_name\" class=\"form-control\" placeholder=\"First Name\"/>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<label for=\"last_name\">Last Name <span class=\"red-asterisk\">*</span></label>
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"shippingAddress[last_name]\" value=\"";
        // line 198
        echo formdata("last_name", $this->getAttribute(($context["shippingAddress"] ?? null), "last_name", []));
        echo "\" required id=\"last_name\" class=\"form-control\" placeholder=\"Last Name\"/>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<label for=\"email\">Email <span class=\"red-asterisk\">*</span></label>
\t\t\t\t\t\t\t\t\t\t<input type=\"email\" name=\"shippingAddress[email]\" value=\"";
        // line 204
        echo formdata("email", $this->getAttribute(($context["shippingAddress"] ?? null), "email", []));
        echo "\" required id=\"email\" class=\"form-control\" placeholder=\"Email\"/>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<label for=\"phone\">Phone <span class=\"red-asterisk\">*</span></label>
\t\t\t\t\t\t\t\t\t\t<input type=\"number\" name=\"shippingAddress[phone]\" value=\"";
        // line 210
        echo formdata("phone", $this->getAttribute(($context["shippingAddress"] ?? null), "phone", []));
        echo "\" required id=\"phone\" class=\"form-control\" placeholder=\"Phone\"/>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<label for=\"country\">Country <span class=\"red-asterisk\">*</span></label>
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"shippingAddress[country]\" value=\"Tanzania\" required id=\"country\" class=\"form-control\" placeholder=\"Country\"/>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<label for=\"city\">Region <span class=\"red-asterisk\">*</span></label>
\t\t\t\t\t\t\t\t\t\t";
        // line 223
        echo "\t\t\t\t\t\t\t\t\t\t<select name=\"shippingAddress[region]\" class=\"form-control\" id=\"region\" onchange=\"myFunctiondepartment()\">
\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
        // line 224
        echo twig_escape_filter($this->env, $this->getAttribute(($context["addressBook"] ?? null), "region", []), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["addressBook"] ?? null), "region", []), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t\t";
        // line 225
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["distircts"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["distirct"]) {
            // line 226
            echo "\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["distirct"], "name", []), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["distirct"], "name", []), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['distirct'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 228
        echo "
\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<label for=\"region\">District <span class=\"red-asterisk\">*</span></label>
\t\t\t\t\t\t\t\t\t\t";
        // line 236
        echo "\t\t\t\t\t\t\t\t\t\t<select name=\"shippingAddress[city]\" class=\"form-control\" id=\"city\">
\t\t\t\t\t\t\t\t\t\t\t<option  value=\"";
        // line 237
        echo twig_escape_filter($this->env, $this->getAttribute(($context["addressBook"] ?? null), "city", []), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["addressBook"] ?? null), "city", []), "html", null, true);
        echo "</option>

\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<label for=\"address\">Street Address <span class=\"red-asterisk\">*</span></label>
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"shippingAddress[address]\" value=\"";
        // line 245
        echo formdata("address", $this->getAttribute(($context["shippingAddress"] ?? null), "address", []));
        echo "\" required id=\"address\" class=\"form-control\" placeholder=\"Address\"/>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<label for=\"postal_code\">Postal Code</label>
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"shippingAddress[postal_code]\" value=\"";
        // line 251
        echo formdata("postal_code", $this->getAttribute(($context["shippingAddress"] ?? null), "postal_code", []));
        echo "\" id=\"postal_code\" class=\"form-control\" placeholder=\"Postal Code\"/>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<input class=\"chkBike\" type=\"checkbox\" name=\"save_address\" value=\"Yes\" id=\"save_address\"/>
\t\t\t\t\t\t\t\t\t\t<label for=\"save_address\" class=\"form-label\">Save as default shipping address</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<h3>Shipping Method <span class=\"red-asterisk\">*</span></h3>
\t\t\t\t\t\t\t<ul class=\"sec-shipping-method\">
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"shipping_method\" v-model=\"ship\" checked=\"checked\" value=\"Self_Collection\" id=\"Self-Collection\">
\t\t\t\t\t\t\t\t\t<label for=\"Self-Collection\">Self-Collection (Free)</label>
\t\t\t\t\t\t\t\t\t<span class=\"glyphicon glyphicon-info-sign\" v-on:click=\"first()\"></span>
\t\t\t\t\t\t\t\t\t<div class=\"alert alert-info bank-detail\" v-show=\"toggleBankDetailBox\">
\t\t\t\t\t\t\t\t\t\tThis shipping method allows you to self-collect your goods at our physical stores located <a href=\"";
        // line 268
        echo twig_escape_filter($this->env, base_url("page/contact-us"), "html", null, true);
        echo "\">here</a>.<br/>
\t\t\t\t\t\t\t\t\t\tThe method is recommended for customers in Dar es Salaam.
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"shipping_method\" v-model=\"ship\" value=\"Cash_On_Delivery\" id=\"cod\">
\t\t\t\t\t\t\t\t\t<label for=\"cod\">Cash On Delivery (Estimated shipping fee: TZS 10,000)</label>
\t\t\t\t\t\t\t\t\t<span class=\"glyphicon glyphicon-info-sign\" v-on:click=\"second()\"></span>
\t\t\t\t\t\t\t\t\t<div class=\"alert alert-info bank-detail\" v-show=\"toggleCODBox\">
\t\t\t\t\t\t\t\t\t\tThis shipping method allows you to pay for goods on delivery. The actual shipping fee may deviate from the estimated one (of TZS 10,000)
\t\t\t\t\t\t\t\t\t\tdepending upon the following factors: total weight and delicacy of the purchased goods, and volume of the packaging material.<br />
\t\t\t\t\t\t\t\t\t\tThis method is recommended for customers in Dar es Salaam.
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<input type=\"radio\" v-model=\"ship\" name=\"shipping_method\" value=\"BAFREDO_Savings\" id=\"bafsaving\">
\t\t\t\t\t\t\t\t\t<label for=\"bafsaving\">Upcountry Delivery (Estimated shipping fee: TZS 15,000)</label>
\t\t\t\t\t\t\t\t\t<span class=\"glyphicon glyphicon-info-sign\" v-on:click=\"third()\"></span>
\t\t\t\t\t\t\t\t\t<div class=\"alert alert-info bank-detail\" v-show=\"toggleBAFSAVINGBox\">
\t\t\t\t\t\t\t\t\t\tThis shipping method is recommended for customers in regions outside Dar es Salaam. <br />
\t\t\t\t\t\t\t\t\t\tThe actual shipping fee may deviate from the estimated one (of TZS 15,000) depending upon the following factors: total weight and delicacy of the purchased goods, and volume of the packaging material.
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>

\t\t\t\t\t\t\t<h3>Payment Method <span class=\"red-asterisk\">*</span></h3>
\t\t\t\t\t\t\t<ul class=\"sec-payment-method\">
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"payment_method\" value=\"bank_transfer\" checked id=\"banktransfer\" v-on:click=\"toggleBankDetailBox\">
\t\t\t\t\t\t\t\t\t<label for=\"banktransfer\" data-toggle=\"tooltip\" title=\"This payment method involves transferring money directly to our bank account.
\t\t\t\t\t\t\t\t\t\t   Please use your Order ID as the payment reference. Your order may not be shipped until the transfer has been confirmed.\">
\t\t\t\t\t\t\t\t\t\tDirect Bank Transfer
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<div class=\"alert alert-info bank-detail\" v-show=\"bankDetailInfoBox\">
\t\t\t\t\t\t\t\t\t\tThis payment method involves transferring money directly to our bank account.
\t\t\t\t\t\t\t\t\t\tPlease use your Order ID as the payment reference. Your order may not be shipped until the transfer has been confirmed.
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"payment_method\" value=\"tigopesa\" id=\"tigopesa\">
\t\t\t\t\t\t\t\t\t<label for=\"tigopesa\" data-toggle=\"tooltip\" title=\"You will be redirected to Tigo Pesa Secure Payment Gateway to complete your payment.\">
\t\t\t\t\t\t\t\t\t\tTigo Pesa - Online <img src=\"";
        // line 309
        echo asset("uploads/tigopesa.jpeg");
        echo "\" alt=\"tigopesa\">
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"payment_method\" value=\"pesapal\" id=\"pesapal\">
\t\t\t\t\t\t\t\t\t<label for=\"pesapal\" data-toggle=\"tooltip\" title=\"This payment method uses Pesapal Gateway, which integrates the following options: Mobile Money Transfer (Tigo Pesa, M-Pesa, and Airtel Money) and Electronic Cards (Visa and MasterCard).\">
\t\t\t\t\t\t\t\t\t\tPESAPAL (Tigo Pesa, M-Pesa, Visa, and MasterCard) <img src=\"";
        // line 315
        echo asset("uploads/pesapal.png");
        echo "\" alt=\"tigopesa\">
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>

\t\t\t\t\t\t\t<h3>Order notes (optional)</h3>
\t\t\t\t\t\t\t<textarea class=\"form-control\" name=\"order_notes\">";
        // line 321
        echo formdata("order_notes");
        echo "</textarea>

\t\t\t\t\t\t\t<div class=\"info-message\">
\t\t\t\t\t\t\t\tNote: The personal data you submitted to our website may be used to process your order, improve your shopping experience, and/or achieve other user-centered goals described in our <a href=\"";
        // line 324
        echo twig_escape_filter($this->env, base_url("page/privacy-policy"), "html", null, true);
        echo "\">privacy policy</a>.
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<p class=\"sec-agreement\">
\t\t\t\t\t\t\t\t<input class=\"chkBike\" type=\"checkbox\" name=\"agreement_flag\" required value=\"1\" id=\"agreement_flag\">
\t\t\t\t\t\t\t\t<label for=\"agreement_flag\">I have read and agreed the <a href=\"";
        // line 329
        echo twig_escape_filter($this->env, base_url("page/privacy-policy"), "html", null, true);
        echo "\">Privacy Policy</a> and <a href=\"";
        echo twig_escape_filter($this->env, base_url("page/terms-conditions"), "html", null, true);
        echo "\">Terms & Conditions</a> of the website. <span class=\"red-asterisk\">*</span></label>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<div class=\"cartListFrame\">
\t\t\t\t\t\t\t\t<h3>SHOPPING CART</h3>
\t\t\t\t\t\t\t\t<table class=\"table cart-table\">
\t\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<th>Product Name</th>
\t\t\t\t\t\t\t\t\t\t\t<th>Price</th>
\t\t\t\t\t\t\t\t\t\t\t<th>Quantity</th>
\t\t\t\t\t\t\t\t\t\t\t<th>Total</th>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t\t<tr v-for=\"item in cart_checkout\">
\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t<img v-bind:src=\"productImage(item.image)\" v-bind:alt=\"item.name\" v-bind:title=\"item.name\" class=\"img-thumbnail\">
\t\t\t\t\t\t\t\t\t\t\t\t<p v-text=\"item.name\"></p>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t\t<td v-text=\"item.currency +' '+ item.price\"></td>
\t\t\t\t\t\t\t\t\t\t\t<td v-text=\"item.quantity\"></td>
\t\t\t\t\t\t\t\t\t\t\t<td v-text=\"item.currency +' '+ (item.price * item.quantity)\"></td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t\t<div class=\"cart-footer\">
\t\t\t\t\t\t\t\t\t<table>
\t\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td>Subtotal</td>
\t\t\t\t\t\t\t\t\t\t\t<td><span v-text=\"subtotal\"></span></td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td>Tax</td>
\t\t\t\t\t\t\t\t\t\t\t<td><span v-text=\"tax\"></span></td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td>Shipping</td>
\t\t\t\t\t\t\t\t\t\t\t<td><span v-text=\"shipping\"></span></td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td>Total</td>
\t\t\t\t\t\t\t\t\t\t\t<td><span v-text=\"total\"></span></td>
\t\t\t\t\t\t\t\t\t\t</tr>

\t\t\t\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"row footer-row\">
\t\t\t\t\t\t<div class=\"col-md-4\">
\t\t\t\t\t\t\tSubtotal: <span v-text=\"subtotal\"></span>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-4\">
\t\t\t\t\t\t\tTax: <span v-text=\"tax\"></span>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-4\">
\t\t\t\t\t\t\tTotal: <span v-text=\"total\"></span>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"btn-contine\">
\t\t\t\t\t\t<button type=\"submit\" class=\"btn-confirm\">Confirm Order</button>
\t\t\t\t\t</div>
\t\t\t\t</form>
            </div>
        </div>
    </div>
";
    }

    // line 401
    public function block_scripts($context, array $blocks = [])
    {
        // line 402
        echo "\t<script>

\t\tfunction myFunctiondepartment() {
\t\t\t\$('#city').empty();
\t\t\tvar x = document.getElementById(\"region\").value;
\t\t\t\$.ajax({
\t\t\t\turl: \"";
        // line 408
        echo twig_escape_filter($this->env, site_url("Account/getregion"), "html", null, true);
        echo "\",
\t\t\t\ttype: 'POST',
\t\t\t\tdata: {'name' : x},
\t\t\t\tsuccess: function(msg) {
\t\t\t\t\tvar data = JSON.parse(msg);
\t\t\t\t\t\$.each(data, function( index, item ) {
\t\t\t\t\t\tvar option = document.createElement(\"option\");
\t\t\t\t\t\toption.text = item.name;
\t\t\t\t\t\toption.value = item.name;
\t\t\t\t\t\tvar select = document.getElementById(\"city\");
\t\t\t\t\t\tselect.appendChild(option);
\t\t\t\t\t});

\t\t\t\t}
\t\t\t});
\t\t}
\t</script>
";
    }

    public function getTemplateName()
    {
        return "cart/checkout.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  534 => 408,  526 => 402,  523 => 401,  445 => 329,  437 => 324,  431 => 321,  422 => 315,  413 => 309,  369 => 268,  349 => 251,  340 => 245,  327 => 237,  324 => 236,  315 => 228,  304 => 226,  300 => 225,  294 => 224,  291 => 223,  276 => 210,  267 => 204,  258 => 198,  249 => 192,  224 => 170,  216 => 165,  212 => 164,  206 => 160,  203 => 159,  44 => 3,  41 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "cart/checkout.twig", "/home/bafredoc/new.bafredo.com/application/views/cart/checkout.twig");
    }
}
