<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/product.twig */
class __TwigTemplate_5da6f9b8300dccfacfdb00e81271a26f353193a8a15ae5971eb3bce326c79304 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<a title=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "name", []), "html", null, true);
        echo "\" href='";
        echo twig_escape_filter($this->env, base_url(("product/detail/" . $this->getAttribute(($context["product"] ?? null), "slug", []))), "html", null, true);
        echo "'>
<div class=\"img\">
        <img src='";
        // line 3
        echo asset(("uploads/product/thumbnail/" . $this->getAttribute(($context["product"] ?? null), "image", [])));
        echo "' alt=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "name", []), "html", null, true);
        echo "\" title=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "name", []), "html", null, true);
        echo "\" class=\"img-responsive\"/>
</div>
</a>
<div class=\"title\">
    <a title=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "name", []), "html", null, true);
        echo "\" href=\"";
        echo twig_escape_filter($this->env, base_url(("product/detail/" . $this->getAttribute(($context["product"] ?? null), "slug", []))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "name", []), "html", null, true);
        echo "</a>
</div>
<div class=\"btns\">
    <b class=\"price\">";
        // line 10
        echo twig_escape_filter($this->env, (($this->getAttribute(($context["product"] ?? null), "currency", []) . " ") . $this->getAttribute(($context["product"] ?? null), "price", [])), "html", null, true);
        echo "</b>
    <span>
        <button type=\"button\" v-on:click=\"addToCart(";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "toJson", [], "method"), "html", null, true);
        echo ")\"><i class=\"iconfont icon-cart\"></i></button>
    </span>
</div>
<div class=\"btns\">Stock: ";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "quantity", []), "html", null, true);
        echo "</div>";
    }

    public function getTemplateName()
    {
        return "partials/product.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  70 => 15,  64 => 12,  59 => 10,  49 => 7,  38 => 3,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "partials/product.twig", "/home/bafredoc/new.bafredo.com/application/views/partials/product.twig");
    }
}
