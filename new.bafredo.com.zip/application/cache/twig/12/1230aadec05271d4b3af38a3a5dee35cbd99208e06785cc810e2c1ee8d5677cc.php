<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/home/bloglist.twig */
class __TwigTemplate_52c7605bf96d17faec47809c3640938a4615392808882fcc29a0721840dec87f extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<ul>
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["blogs"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["blog"]) {
            // line 3
            echo "        <li>
            <div class=\"titleBG\"></div>
            <a href='";
            // line 5
            echo twig_escape_filter($this->env, base_url(("blog/detail/" . $this->getAttribute($context["blog"], "getSlug", [], "method"))), "html", null, true);
            echo "' >
            <div class=\"title\">";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute($context["blog"], "getBlogName", [], "method"), "html", null, true);
            echo "</div>
            </a>
            <div class=\"img\">
                <a title=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute($context["blog"], "getBlogName", [], "method"), "html", null, true);
            echo "\" href='";
            echo twig_escape_filter($this->env, base_url(("blog/detail/" . $this->getAttribute($context["blog"], "getSlug", [], "method"))), "html", null, true);
            echo "'>
                    <img alt=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute($context["blog"], "getBlogName", [], "method"), "html", null, true);
            echo "\" src='";
            echo asset(("front/uploads/blog/" . $this->getAttribute($context["blog"], "getImage", [], "method")));
            echo "' width=\"380px\" height=\"252px\">
                </a>
            </div>
        </li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['blog'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "</ul>";
    }

    public function getTemplateName()
    {
        return "partials/home/bloglist.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  70 => 15,  57 => 10,  51 => 9,  45 => 6,  41 => 5,  37 => 3,  33 => 2,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "partials/home/bloglist.twig", "/home/bafredoc/new.bafredo.com/application/views/partials/home/bloglist.twig");
    }
}
